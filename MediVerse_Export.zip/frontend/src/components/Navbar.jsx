import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  HeartPulse, 
  Bot, 
  Video, 
  FileText, 
  Search, 
  Info, 
  PhoneCall, 
  User, 
  Stethoscope, 
  LogOut, 
  Menu, 
  X,
  ChevronDown,
  Sparkles
} from 'lucide-react';

export default function Navbar({ activePage, setActivePage }) {
  const { user, profile, logout, quickLogin } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [demoMenuOpen, setDemoMenuOpen] = useState(false);

  const handleNav = (page) => {
    setActivePage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickLogin = async (role) => {
    try {
      await quickLogin(role);
      setDemoMenuOpen(false);
      if (role === 'patient') {
        setActivePage('patient-dashboard');
      } else {
        setActivePage('doctor-dashboard');
      }
    } catch (err) {
      alert("Demo login error: " + err.message);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm transition-all">
      {/* Top emergency notice bar */}
      <div className="bg-gradient-to-r from-mediblue-700 via-mediblue-600 to-primary-700 text-white text-xs py-1.5 px-4 text-center font-medium flex items-center justify-center gap-3">
        <span className="flex items-center gap-1.5">
          <HeartPulse className="w-3.5 h-3.5 animate-pulse" />
          <span>Need urgent assistance? 24/7 Digital Care Hotline: <strong>1-800-MEDIVERSE</strong></span>
        </span>
        <span className="hidden md:inline-block opacity-60">|</span>
        <span className="hidden md:inline-block">AI Health Triage available 24/7 free of charge</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 py-3">
          
          {/* Logo & Tagline */}
          <div 
            onClick={() => handleNav('home')} 
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-mediblue-600 to-primary-500 flex items-center justify-center text-white shadow-md shadow-mediblue-500/20 group-hover:scale-105 transition-transform">
              <HeartPulse className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-2xl font-bold tracking-tight text-slate-900 group-hover:text-mediblue-600 transition-colors">
                  Medi<span className="text-primary-600">Verse</span>
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-primary-100 text-primary-800 rounded">
                  AI Health
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium -mt-0.5 hidden sm:block">
                Connecting People to Better Healthcare
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => handleNav('home')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activePage === 'home' ? 'text-mediblue-600 bg-mediblue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Home
            </button>

            <button
              onClick={() => handleNav('doctor-search')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                activePage === 'doctor-search' ? 'text-mediblue-600 bg-mediblue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Search className="w-4 h-4 text-slate-400" />
              Find Doctors
            </button>

            <button
              onClick={() => handleNav('ai-assistant')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                activePage === 'ai-assistant' ? 'text-primary-700 bg-primary-50 ring-1 ring-primary-200' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Bot className="w-4 h-4 text-primary-600" />
              AI Assistant
              <span className="w-2 h-2 rounded-full bg-primary-500 animate-ping"></span>
            </button>

            <button
              onClick={() => handleNav('telemedicine')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                activePage === 'telemedicine' ? 'text-mediblue-600 bg-mediblue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Video className="w-4 h-4 text-slate-400" />
              Telemedicine
            </button>

            <button
              onClick={() => handleNav('digital-records')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                activePage === 'digital-records' ? 'text-mediblue-600 bg-mediblue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4 text-slate-400" />
              Health Records
            </button>

            <button
              onClick={() => handleNav('about')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activePage === 'about' ? 'text-mediblue-600 bg-mediblue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              About
            </button>

            <button
              onClick={() => handleNav('contact')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activePage === 'contact' ? 'text-mediblue-600 bg-mediblue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Quick Demo Access Button */}
            <div className="relative">
              <button
                onClick={() => setDemoMenuOpen(!demoMenuOpen)}
                className="px-3 py-1.5 rounded-lg border border-amber-300 bg-amber-50 text-amber-800 text-xs font-semibold flex items-center gap-1.5 hover:bg-amber-100 transition-colors shadow-xs"
                title="Instant login with pre-populated demo data"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                1-Click Demo Login
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {demoMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-100">
                    Select Test Account:
                  </div>
                  <button
                    onClick={() => handleQuickLogin('patient')}
                    className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-slate-50 text-sm flex items-center gap-2.5 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-full bg-mediblue-100 text-mediblue-700 flex items-center justify-center font-bold text-xs">
                      P
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">John Doe (Patient)</div>
                      <div className="text-xs text-slate-500">patient@mediverse.com</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleQuickLogin('doctor')}
                    className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-slate-50 text-sm flex items-center gap-2.5 transition-colors"
                  >
                    <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-xs">
                      Dr
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800">Dr. Sarah (Cardiology)</div>
                      <div className="text-xs text-slate-500">dr.sarah@mediverse.com</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {user ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                <button
                  onClick={() => handleNav(user.role === 'doctor' ? 'doctor-dashboard' : 'patient-dashboard')}
                  className="px-3 py-2 rounded-lg bg-mediblue-50 hover:bg-mediblue-100 text-mediblue-800 font-medium text-sm flex items-center gap-2 transition-colors border border-mediblue-200"
                >
                  <div className="w-6 h-6 rounded-full bg-mediblue-600 text-white flex items-center justify-center text-xs font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <span>{user.name.split(' ')[0]}</span>
                  <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-mediblue-200 text-mediblue-900">
                    {user.role}
                  </span>
                </button>
                <button
                  onClick={logout}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleNav('patient-login')}
                  className="px-3 py-2 rounded-lg text-sm font-semibold text-slate-700 hover:text-mediblue-700 hover:bg-slate-100 transition-colors flex items-center gap-1.5"
                >
                  <User className="w-4 h-4 text-slate-500" />
                  Patient Portal
                </button>
                <button
                  onClick={() => handleNav('doctor-login')}
                  className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-mediblue-600 to-primary-600 hover:from-mediblue-700 hover:to-primary-700 transition-all shadow-sm shadow-mediblue-500/25 flex items-center gap-1.5"
                >
                  <Stethoscope className="w-4 h-4" />
                  Doctor Portal
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-2 shadow-xl">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-100">
            <button
              onClick={() => handleQuickLogin('patient')}
              className="px-3 py-2 bg-mediblue-50 text-mediblue-800 text-xs font-semibold rounded-lg text-center border border-mediblue-200"
            >
              ⚡ Demo Patient (John)
            </button>
            <button
              onClick={() => handleQuickLogin('doctor')}
              className="px-3 py-2 bg-primary-50 text-primary-800 text-xs font-semibold rounded-lg text-center border border-primary-200"
            >
              ⚡ Demo Doctor (Sarah)
            </button>
          </div>

          <button
            onClick={() => handleNav('home')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Home
          </button>
          <button
            onClick={() => handleNav('doctor-search')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-2"
          >
            <Search className="w-4 h-4 text-slate-400" /> Find Doctors
          </button>
          <button
            onClick={() => handleNav('ai-assistant')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-primary-700 bg-primary-50 flex items-center gap-2"
          >
            <Bot className="w-4 h-4 text-primary-600" /> AI Health Assistant
          </button>
          <button
            onClick={() => handleNav('telemedicine')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-2"
          >
            <Video className="w-4 h-4 text-slate-400" /> Telemedicine Consultation
          </button>
          <button
            onClick={() => handleNav('digital-records')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-2"
          >
            <FileText className="w-4 h-4 text-slate-400" /> Digital Health Records
          </button>
          <button
            onClick={() => handleNav('about')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            About Us
          </button>
          <button
            onClick={() => handleNav('contact')}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            Contact
          </button>

          <div className="pt-3 border-t border-slate-200 space-y-2">
            {user ? (
              <div className="space-y-2">
                <button
                  onClick={() => handleNav(user.role === 'doctor' ? 'doctor-dashboard' : 'patient-dashboard')}
                  className="w-full py-2.5 bg-mediblue-600 text-white font-medium rounded-lg text-center"
                >
                  Go to {user.role === 'doctor' ? 'Doctor' : 'Patient'} Dashboard ({user.name})
                </button>
                <button
                  onClick={logout}
                  className="w-full py-2 bg-slate-100 text-slate-700 font-medium rounded-lg text-center"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleNav('patient-login')}
                  className="w-full py-2.5 text-center text-sm font-semibold border border-slate-300 rounded-lg text-slate-700"
                >
                  Patient Login
                </button>
                <button
                  onClick={() => handleNav('doctor-login')}
                  className="w-full py-2.5 text-center text-sm font-semibold bg-mediblue-600 text-white rounded-lg"
                >
                  Doctor Login
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
