import React from 'react';
import { HeartPulse, Bot, Video, FileText, Phone, Mail, MapPin, ShieldCheck } from 'lucide-react';

export default function Footer({ setActivePage }) {
  const handleNav = (page) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          
          {/* Brand & Vision */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-mediblue-500 to-primary-400 flex items-center justify-center text-white shadow-md">
                <HeartPulse className="w-5 h-5" />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">
                Medi<span className="text-primary-400">Verse</span>
              </span>
            </div>
            
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              <strong>Your Health, Our Priority – Healthcare Anytime, Anywhere.</strong>
              <br />
              Connecting people, particularly in rural and underserved communities, to certified medical specialists and AI-assisted preliminary health triage.
            </p>

            <div className="flex items-center gap-2 text-xs text-primary-400 bg-primary-950/60 border border-primary-800/60 rounded-lg p-2.5 max-w-md">
              <ShieldCheck className="w-4 h-4 shrink-0 text-primary-400" />
              <span>HIPAA Compliant Architecture • Role-Based Protected Health Information (PHI)</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">Platform</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-primary-400 transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('doctor-search')} className="hover:text-primary-400 transition-colors">
                  Find Doctors
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('ai-assistant')} className="hover:text-primary-400 transition-colors">
                  AI Health Assistant
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('telemedicine')} className="hover:text-primary-400 transition-colors">
                  Telemedicine Rooms
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('digital-records')} className="hover:text-primary-400 transition-colors">
                  Digital Health Records
                </button>
              </li>
            </ul>
          </div>

          {/* Portals & Accounts */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">Access Portals</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => handleNav('patient-login')} className="hover:text-primary-400 transition-colors">
                  Patient Portal Login
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('doctor-login')} className="hover:text-primary-400 transition-colors">
                  Doctor Portal Login
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('patient-dashboard')} className="hover:text-primary-400 transition-colors">
                  Patient Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('doctor-dashboard')} className="hover:text-primary-400 transition-colors">
                  Doctor Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-primary-400 transition-colors">
                  About MediVerse
                </button>
              </li>
            </ul>
          </div>

          {/* Emergency & Support */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold uppercase tracking-wider text-white">24/7 Help Desk</h4>
            <ul className="space-y-3 text-sm text-slate-400">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-primary-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">1-800-MEDIVERSE</div>
                  <div className="text-xs text-slate-400">Toll-free 24/7 Consultation</div>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-primary-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">care@mediverse.health</div>
                  <div className="text-xs text-slate-400">Response within 2 hours</div>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-primary-400 shrink-0 mt-0.5" />
                <span className="text-xs leading-relaxed">
                  MediVerse Digital Health Tower, Suite 400, Healthcare City
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p className="max-w-2xl text-center md:text-left leading-relaxed">
            <span className="text-amber-400 font-semibold">Important Medical Notice:</span> MediVerse is a digital health platform providing remote telemedicine connectivity and AI preliminary symptom guidance. It is not an emergency response provider. In the event of a medical emergency, please call your local emergency service immediately.
          </p>
          <div className="text-center md:text-right shrink-0">
            <div>© {new Date().getFullYear()} MediVerse Inc. All rights reserved.</div>
            <div className="text-slate-400 mt-1">Connecting People to Better Healthcare.</div>
          </div>
        </div>
      </div>
    </footer>
  );
}
