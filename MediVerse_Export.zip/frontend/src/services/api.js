const API_BASE = '/api';

function getAuthHeaders() {
  const token = localStorage.getItem('mediverse_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };
}

export const api = {
  // Auth
  async login(email, password) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || 'Login failed');
    }
    return res.json();
  },

  async register(data) {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || 'Registration failed');
    }
    return res.json();
  },

  async getCurrentUser() {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to fetch profile');
    return res.json();
  },

  async getDemoCredentials() {
    const res = await fetch(`${API_BASE}/auth/demo-credentials`);
    if (!res.ok) throw new Error('Failed to fetch demo credentials');
    return res.json();
  },

  // Doctors
  async getDoctors(specialization = '', search = '') {
    const params = new URLSearchParams();
    if (specialization && specialization !== 'All') params.append('specialization', specialization);
    if (search) params.append('search', search);

    const res = await fetch(`${API_BASE}/doctors?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to load doctors');
    return res.json();
  },

  async getDoctorById(id) {
    const res = await fetch(`${API_BASE}/doctors/${id}`);
    if (!res.ok) throw new Error('Failed to fetch doctor details');
    return res.json();
  },

  async getSpecializations() {
    const res = await fetch(`${API_BASE}/doctors/specializations/list`);
    if (!res.ok) throw new Error('Failed to fetch specializations');
    return res.json();
  },

  // Appointments
  async getAppointments() {
    const res = await fetch(`${API_BASE}/appointments`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to fetch appointments');
    return res.json();
  },

  async bookAppointment(data) {
    const res = await fetch(`${API_BASE}/appointments`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || 'Failed to book appointment');
    }
    return res.json();
  },

  async updateAppointment(id, data) {
    const res = await fetch(`${API_BASE}/appointments/${id}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to update appointment');
    return res.json();
  },

  async getAppointmentById(id) {
    const res = await fetch(`${API_BASE}/appointments/${id}`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to fetch appointment details');
    return res.json();
  },

  // Medical Records
  async getMedicalRecords(patientId = null, recordType = null) {
    const params = new URLSearchParams();
    if (patientId) params.append('patient_id', patientId);
    if (recordType && recordType !== 'All') params.append('record_type', recordType);

    const res = await fetch(`${API_BASE}/records?${params.toString()}`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to fetch medical records');
    return res.json();
  },

  async createMedicalRecord(data) {
    const res = await fetch(`${API_BASE}/records`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create medical record');
    return res.json();
  },

  // AI Health Assistant
  async sendAIChat(message, sessionId = 'default') {
    const res = await fetch(`${API_BASE}/ai/chat`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ message, session_id: sessionId })
    });
    if (!res.ok) throw new Error('Failed to communicate with AI Assistant');
    return res.json();
  },

  async getAIHistory(sessionId = 'default') {
    const res = await fetch(`${API_BASE}/ai/history?session_id=${sessionId}`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to load AI chat history');
    return res.json();
  },

  async clearAIHistory(sessionId = 'default') {
    const res = await fetch(`${API_BASE}/ai/history?session_id=${sessionId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    if (!res.ok) throw new Error('Failed to clear chat history');
    return res.json();
  },

  // Consultation Room / WebRTC coordination
  async getRoomState(roomId) {
    const res = await fetch(`${API_BASE}/consultations/${roomId}`);
    if (!res.ok) throw new Error('Failed to get room state');
    return res.json();
  },

  async joinRoom(roomId, participant) {
    const res = await fetch(`${API_BASE}/consultations/${roomId}/join`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(participant)
    });
    return res.json();
  },

  async sendInCallChat(roomId, msg) {
    const res = await fetch(`${API_BASE}/consultations/${roomId}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg)
    });
    return res.json();
  },

  // Contact
  async submitContact(data) {
    const res = await fetch(`${API_BASE}/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  }
};
