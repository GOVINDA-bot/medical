import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// 12 Pages
import HomePage from './pages/HomePage';
import PatientAuthPage from './pages/PatientAuthPage';
import DoctorAuthPage from './pages/DoctorAuthPage';
import PatientDashboardPage from './pages/PatientDashboardPage';
import DoctorDashboardPage from './pages/DoctorDashboardPage';
import DoctorSearchPage from './pages/DoctorSearchPage';
import AppointmentBookingPage from './pages/AppointmentBookingPage';
import TelemedicinePage from './pages/TelemedicinePage';
import AIAssistantPage from './pages/AIAssistantPage';
import DigitalRecordsPage from './pages/DigitalRecordsPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';

export default function App() {
  const [activePage, setActivePage] = useState('home');
  const [selectedDoctorForBooking, setSelectedDoctorForBooking] = useState(null);
  const [consultationRoomId, setConsultationRoomId] = useState('room-mediverse-101');

  const renderCurrentPage = () => {
    switch (activePage) {
      case 'home':
        return (
          <HomePage 
            setActivePage={setActivePage} 
            setSelectedDoctorForBooking={setSelectedDoctorForBooking} 
          />
        );
      case 'patient-login':
        return <PatientAuthPage setActivePage={setActivePage} />;
      case 'doctor-login':
        return <DoctorAuthPage setActivePage={setActivePage} />;
      case 'patient-dashboard':
        return (
          <PatientDashboardPage 
            setActivePage={setActivePage} 
            setConsultationRoomId={setConsultationRoomId}
            setSelectedDoctorForBooking={setSelectedDoctorForBooking}
          />
        );
      case 'doctor-dashboard':
        return (
          <DoctorDashboardPage 
            setActivePage={setActivePage} 
            setConsultationRoomId={setConsultationRoomId}
          />
        );
      case 'doctor-search':
        return (
          <DoctorSearchPage 
            setActivePage={setActivePage} 
            setSelectedDoctorForBooking={setSelectedDoctorForBooking} 
          />
        );
      case 'appointment-booking':
        return (
          <AppointmentBookingPage 
            setActivePage={setActivePage} 
            selectedDoctorForBooking={selectedDoctorForBooking}
            setConsultationRoomId={setConsultationRoomId}
          />
        );
      case 'telemedicine':
        return (
          <TelemedicinePage 
            setActivePage={setActivePage} 
            consultationRoomId={consultationRoomId} 
          />
        );
      case 'ai-assistant':
        return (
          <AIAssistantPage 
            setActivePage={setActivePage} 
            setSelectedDoctorForBooking={setSelectedDoctorForBooking}
          />
        );
      case 'digital-records':
        return <DigitalRecordsPage setActivePage={setActivePage} />;
      case 'about':
        return <AboutPage setActivePage={setActivePage} />;
      case 'contact':
        return <ContactPage />;
      default:
        return (
          <HomePage 
            setActivePage={setActivePage} 
            setSelectedDoctorForBooking={setSelectedDoctorForBooking} 
          />
        );
    }
  };

  return (
    <AuthProvider>
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
        <Navbar activePage={activePage} setActivePage={setActivePage} />
        
        <main className="flex-1">
          {renderCurrentPage()}
        </main>

        <Footer setActivePage={setActivePage} />
      </div>
    </AuthProvider>
  );
}
