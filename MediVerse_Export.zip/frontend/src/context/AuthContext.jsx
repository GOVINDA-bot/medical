import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('mediverse_token') || null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadUser() {
      if (token) {
        try {
          const data = await api.getCurrentUser();
          setUser(data.user);
          setProfile(data.profile);
        } catch (err) {
          console.error("Auto login error:", err);
          logout();
        }
      }
      setLoading(false);
    }
    loadUser();
  }, [token]);

  const login = async (email, password) => {
    const data = await api.login(email, password);
    localStorage.setItem('mediverse_token', data.token);
    setToken(data.token);
    setUser(data.user);
    setProfile(data.profile);
    return data;
  };

  const register = async (userData) => {
    const data = await api.register(userData);
    localStorage.setItem('mediverse_token', data.token);
    setToken(data.token);
    setUser(data.user);
    setProfile(data.profile);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('mediverse_token');
    setToken(null);
    setUser(null);
    setProfile(null);
  };

  // Convenient 1-click demo login helper for seamless review & presentation
  const quickLogin = async (role = 'patient') => {
    if (role === 'patient') {
      return await login('patient@mediverse.com', 'patient123');
    } else {
      return await login('dr.sarah@mediverse.com', 'doctor123');
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, token, loading, login, register, logout, quickLogin }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
