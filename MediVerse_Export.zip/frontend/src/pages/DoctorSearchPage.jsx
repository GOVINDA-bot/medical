import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { 
  Search, 
  Filter, 
  Star, 
  MapPin, 
  Calendar, 
  Clock, 
  Stethoscope, 
  Award, 
  Globe, 
  ArrowRight,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

const SPECIALTY_OPTIONS = [
  'All',
  'Cardiology',
  'Neurology',
  'Dermatology',
  'Pediatrics',
  'General Medicine'
];

export default function DoctorSearchPage({ setActivePage, setSelectedDoctorForBooking }) {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All');
  const [minRating, setMinRating] = useState(0);

  useEffect(() => {
    async function fetchDoctors() {
      try {
        setLoading(true);
        const data = await api.getDoctors(
          selectedSpecialty === 'All' ? '' : selectedSpecialty,
          searchTerm
        );
        let filtered = data;
        if (minRating > 0) {
          filtered = filtered.filter(d => d.rating >= minRating);
        }
        setDoctors(filtered);
      } catch (err) {
        console.error("Error loading doctors:", err);
      } finally {
        setLoading(false);
      }
    }
    const debounce = setTimeout(fetchDoctors, 250);
    return () => clearTimeout(debounce);
  }, [searchTerm, selectedSpecialty, minRating]);

  const handleBook = (doctor) => {
    setSelectedDoctorForBooking(doctor);
    setActivePage('appointment-booking');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Search Header Banner */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-mediblue-700 bg-mediblue-50 border border-mediblue-200 px-3 py-1 rounded-full inline-block">
          Verified Telemedicine Specialists
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Find the Right Doctor for Your Care
        </h1>
        <p className="text-sm sm:text-base text-slate-600">
          Book immediate high-definition video consultations with top board-certified physicians from leading hospitals.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        
        {/* Search input */}
        <div className="relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by doctor name, specialty, hospital, or symptoms (e.g. chest pain, acne, migraine)..."
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500 text-sm"
          />
        </div>

        {/* Specialty Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Specialty:
          </span>
          {SPECIALTY_OPTIONS.map((spec) => (
            <button
              key={spec}
              onClick={() => setSelectedSpecialty(spec)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedSpecialty === spec
                  ? 'bg-mediblue-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {spec}
            </button>
          ))}
        </div>

      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between">
        <div className="text-sm font-bold text-slate-700">
          Available Doctors ({doctors.length})
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500">Filter rating:</span>
          <select
            value={minRating}
            onChange={(e) => setMinRating(parseFloat(e.target.value))}
            className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white font-medium text-slate-700 text-xs"
          >
            <option value="0">All Ratings</option>
            <option value="4.8">4.8+ Stars</option>
            <option value="4.9">4.9+ Stars</option>
          </select>
        </div>
      </div>

      {/* Doctors Grid */}
      {loading ? (
        <div className="py-20 text-center">
          <div className="w-8 h-8 border-3 border-mediblue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-sm text-slate-500">Locating available telemedicine doctors...</p>
        </div>
      ) : doctors.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 space-y-3">
          <Stethoscope className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No doctors found matching criteria</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search query or reset the specialization filter.
          </p>
          <button
            onClick={() => { setSearchTerm(''); setSelectedSpecialty('All'); setMinRating(0); }}
            className="px-4 py-2 bg-mediblue-50 text-mediblue-700 text-xs font-semibold rounded-lg hover:bg-mediblue-100 transition-colors"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {doctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-xl hover:border-mediblue-300 transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Doctor Avatar & Quick Badges */}
                <div className="flex items-start gap-4">
                  <img
                    src={doc.avatar_url}
                    alt={doc.name}
                    className="w-20 h-20 rounded-2xl object-cover shrink-0 border border-slate-100 shadow-xs"
                  />
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-primary-800 bg-primary-100 px-2 py-0.5 rounded inline-block">
                      {doc.specialization}
                    </span>
                    <h3 className="font-bold text-slate-900 text-base leading-snug">{doc.name}</h3>
                    <div className="text-xs text-slate-500 font-medium truncate max-w-[180px]">
                      {doc.qualification}
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="flex items-center gap-1 font-bold text-slate-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                        <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        {doc.rating}
                      </span>
                      <span className="text-slate-400">({doc.total_reviews} reviews)</span>
                    </div>
                  </div>
                </div>

                {/* Hospital and Experience */}
                <div className="bg-slate-50 p-3 rounded-xl space-y-1 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-mediblue-600 shrink-0" />
                    <span className="truncate">{doc.hospital}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-primary-600 shrink-0" />
                    <span>{doc.experience_years} Years Clinical Practice</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Speaks: {doc.languages || 'English'}</span>
                  </div>
                </div>

                {/* Bio snippet */}
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {doc.bio}
                </p>

                {/* Availability Preview */}
                <div className="text-xs text-slate-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Days: <strong>{doc.available_days}</strong></span>
                </div>
              </div>

              {/* Card Footer: Fee and Book action */}
              <div className="pt-5 mt-5 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Session Fee</span>
                  <div className="text-lg font-extrabold text-slate-900">${doc.consultation_fee}</div>
                </div>

                <button
                  onClick={() => handleBook(doc)}
                  className="px-4 py-2.5 bg-gradient-to-r from-mediblue-600 to-primary-600 hover:from-mediblue-700 hover:to-primary-700 text-white text-xs font-bold rounded-xl shadow-sm transition-all flex items-center gap-1.5"
                >
                  <span>Book Consultation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
}
