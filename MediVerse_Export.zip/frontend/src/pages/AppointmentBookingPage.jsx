import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  Calendar, 
  Clock, 
  Video, 
  Phone, 
  User, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowLeft, 
  Star, 
  AlertCircle,
  Sparkles,
  CreditCard
} from 'lucide-react';

export default function AppointmentBookingPage({ 
  setActivePage, 
  selectedDoctorForBooking, 
  setConsultationRoomId 
}) {
  const { user, profile, quickLogin } = useAuth();
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState(selectedDoctorForBooking || null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [consultationType, setConsultationType] = useState('Video Consultation');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(null);
  const [error, setError] = useState('');

  // Default next 5 days
  const availableDates = Array.from({ length: 5 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i + 1);
    return d.toISOString().split('T')[0];
  });

  const timeSlots = [
    '09:00 AM',
    '10:30 AM',
    '11:45 AM',
    '02:00 PM',
    '03:30 PM',
    '05:00 PM'
  ];

  useEffect(() => {
    async function loadDoctors() {
      try {
        const docs = await api.getDoctors();
        setDoctors(docs);
        if (!selectedDoctor && docs.length > 0) {
          setSelectedDoctor(docs[0]);
        }
      } catch (err) {
        console.error("Error loading doctors for booking:", err);
      }
    }
    loadDoctors();
    if (availableDates.length > 0) {
      setSelectedDate(availableDates[0]);
    }
    setSelectedTime(timeSlots[0]);
  }, []);

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!user) {
      setError("Please log in as a patient to schedule an appointment.");
      return;
    }

    if (user.role !== 'patient') {
      setError("You are currently signed in as a Doctor. Please switch to a Patient account to book a consultation.");
      return;
    }

    if (!selectedDoctor) {
      setError("Please select a doctor.");
      return;
    }

    setLoading(true);
    try {
      const res = await api.bookAppointment({
        doctor_id: selectedDoctor.id,
        appointment_date: selectedDate,
        appointment_time: selectedTime,
        consultation_type: consultationType,
        reason: reason || "Routine Consultation"
      });
      setBookingSuccess(res);
    } catch (err) {
      setError(err.message || "Failed to schedule appointment.");
    } finally {
      setLoading(false);
    }
  };

  const handleDirectDemoLogin = async () => {
    try {
      await quickLogin('patient');
      setError('');
    } catch (err) {
      setError("Login failed: " + err.message);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Back button */}
      <button
        onClick={() => setActivePage('doctor-search')}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Doctor Directory
      </button>

      {bookingSuccess ? (
        <div className="bg-white rounded-3xl border border-emerald-200 p-8 shadow-xl text-center space-y-6 animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Appointment Confirmed
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Your Consultation is Scheduled!
            </h2>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              We have reserved your appointment with <strong>{bookingSuccess.doctor_name}</strong>.
            </p>
          </div>

          {/* Details Card */}
          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 text-xs sm:text-sm text-left max-w-md mx-auto space-y-2.5">
            <div className="flex justify-between border-b border-slate-200 pb-2">
              <span className="text-slate-500">Specialist:</span>
              <span className="font-bold text-slate-900">{bookingSuccess.doctor_name} ({bookingSuccess.doctor_specialization})</span>
            </div>
            <div className="flex justify-between border-b border-slate-200 pb-2">
              <span className="text-slate-500">Date & Time:</span>
              <span className="font-bold text-mediblue-700">{bookingSuccess.appointment_date} at {bookingSuccess.appointment_time}</span>
            </div>
            <div className="flex justify-between border-b border-slate-200 pb-2">
              <span className="text-slate-500">Consultation Format:</span>
              <span className="font-semibold text-slate-800">{bookingSuccess.consultation_type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Meeting Room:</span>
              <span className="font-mono text-xs bg-slate-200 px-2 py-0.5 rounded text-slate-800">{bookingSuccess.meeting_room_id}</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <button
              onClick={() => {
                setConsultationRoomId(bookingSuccess.meeting_room_id);
                setActivePage('telemedicine');
              }}
              className="w-full sm:w-auto px-6 py-3 bg-mediblue-600 hover:bg-mediblue-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
            >
              <Video className="w-4 h-4" />
              Enter Consultation Room Now
            </button>
            <button
              onClick={() => setActivePage('patient-dashboard')}
              className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
            >
              View in Patient Dashboard
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-lg space-y-8">
          
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Schedule Telemedicine Appointment
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Select your consultation preferences, chosen date, and symptom notes.
            </p>
          </div>

          {/* If user is not logged in as a patient */}
          {(!user || user.role !== 'patient') && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 text-xs">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                <span>You need to be signed in as a patient to confirm this booking.</span>
              </div>
              <button
                type="button"
                onClick={handleDirectDemoLogin}
                className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold text-xs rounded-lg shadow-xs flex items-center gap-1.5 shrink-0 self-start sm:self-auto"
              >
                <Sparkles className="w-3.5 h-3.5" />
                1-Click Sign In as John Doe
              </button>
            </div>
          )}

          {error && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleBookingSubmit} className="space-y-6">
            
            {/* Step 1: Doctor Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                1. Select Specialist
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {doctors.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDoctor(doc)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                      selectedDoctor?.id === doc.id
                        ? 'border-mediblue-600 bg-mediblue-50/60 ring-2 ring-mediblue-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <img
                      src={doc.avatar_url}
                      alt={doc.name}
                      className="w-12 h-12 rounded-xl object-cover shrink-0"
                    />
                    <div className="truncate">
                      <div className="font-bold text-slate-900 text-sm truncate">{doc.name}</div>
                      <div className="text-xs text-primary-700 font-semibold">{doc.specialization}</div>
                      <div className="text-[11px] text-slate-500 font-medium">${doc.consultation_fee} / session</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Step 2: Date & Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-mediblue-600" />
                  2. Choose Date
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {availableDates.map((date) => (
                    <button
                      type="button"
                      key={date}
                      onClick={() => setSelectedDate(date)}
                      className={`p-2.5 rounded-xl border text-center transition-all ${
                        selectedDate === date
                          ? 'border-mediblue-600 bg-mediblue-600 text-white font-bold shadow-sm'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 text-xs'
                      }`}
                    >
                      <div className="text-[10px] uppercase font-bold opacity-80">
                        {new Date(date).toLocaleDateString('en-US', { weekday: 'short' })}
                      </div>
                      <div className="text-sm font-extrabold mt-0.5">
                        {new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-mediblue-600" />
                  3. Select Time Slot
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {timeSlots.map((slot) => (
                    <button
                      type="button"
                      key={slot}
                      onClick={() => setSelectedTime(slot)}
                      className={`p-2 rounded-xl border text-xs font-semibold transition-all ${
                        selectedTime === slot
                          ? 'border-primary-600 bg-primary-600 text-white shadow-sm'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 3: Consultation Format */}
            <div className="pt-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                4. Consultation Format
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setConsultationType('Video Consultation')}
                  className={`p-3.5 rounded-2xl border text-left transition-all flex items-center gap-3 ${
                    consultationType === 'Video Consultation'
                      ? 'border-mediblue-600 bg-mediblue-50 ring-2 ring-mediblue-500/20'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-mediblue-100 text-mediblue-700 flex items-center justify-center shrink-0">
                    <Video className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">HD Video Consultation</div>
                    <div className="text-[11px] text-slate-500">Camera & mic enabled (Recommended)</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setConsultationType('Audio Consultation')}
                  className={`p-3.5 rounded-2xl border text-left transition-all flex items-center gap-3 ${
                    consultationType === 'Audio Consultation'
                      ? 'border-mediblue-600 bg-mediblue-50 ring-2 ring-mediblue-500/20'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Audio Tele-Call</div>
                    <div className="text-[11px] text-slate-500">Low bandwidth voice only</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Step 4: Symptoms & Notes */}
            <div className="pt-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                5. Reason for Consultation & Symptoms
              </label>
              <textarea
                rows="3"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Briefly describe your symptoms, duration, or specific medical queries for the doctor..."
                className="w-full p-3 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
              ></textarea>
            </div>

            {/* Summary & Submit */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs text-slate-500">Total Consultation Fee</div>
                <div className="text-xl font-black text-slate-900">
                  ${selectedDoctor?.consultation_fee || 50}.00
                </div>
                <div className="text-[11px] text-emerald-600 font-semibold">Includes digital prescription & follow-up notes</div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="px-6 py-3 bg-gradient-to-r from-mediblue-600 to-primary-600 hover:from-mediblue-700 hover:to-primary-700 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Schedule Visit</span>
                  </>
                )}
              </button>
            </div>

          </form>

        </div>
      )}

    </div>
  );
}
