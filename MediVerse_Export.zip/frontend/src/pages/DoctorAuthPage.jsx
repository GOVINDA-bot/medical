import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Stethoscope, Lock, Mail, Building2, Award, DollarSign, AlertCircle, Sparkles, ArrowRight } from 'lucide-react';

export default function DoctorAuthPage({ setActivePage }) {
  const { login, register, quickLogin } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [specialization, setSpecialization] = useState('Cardiology');
  const [qualification, setQualification] = useState('');
  const [experienceYears, setExperienceYears] = useState('');
  const [hospital, setHospital] = useState('');
  const [consultationFee, setConsultationFee] = useState('50');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        await login(email, password);
      } else {
        await register({
          name: name.startsWith('Dr.') ? name : `Dr. ${name}`,
          email,
          password,
          role: 'doctor',
          phone,
          specialization,
          qualification: qualification || 'MD',
          experience_years: experienceYears ? parseInt(experienceYears) : 5,
          hospital: hospital || 'MediVerse TeleCare Network',
          consultation_fee: consultationFee ? parseFloat(consultationFee) : 50.0
        });
      }
      setActivePage('doctor-dashboard');
    } catch (err) {
      setError(err.message || 'Authentication failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setError('');
    setLoading(true);
    try {
      await quickLogin('doctor');
      setActivePage('doctor-dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="max-w-md w-full space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-primary-100 text-primary-700 items-center justify-center shadow-inner mb-3">
            <Stethoscope className="w-7 h-7" />
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900">
            {isLogin ? 'Doctor Portal Login' : 'Register Medical Provider'}
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Conduct virtual consultations, review patient records & issue prescriptions.
          </p>
        </div>

        {/* Demo 1-Click Banner */}
        <div className="bg-primary-50 border border-primary-200 rounded-xl p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary-700" />
              <span className="text-xs font-bold text-primary-900">Quick College Reviewer Demo:</span>
            </div>
            <span className="text-[10px] font-bold uppercase bg-primary-200 text-primary-900 px-1.5 py-0.5 rounded">
              Pre-filled
            </span>
          </div>
          <p className="text-xs text-primary-800 mt-1">
            Demo account: <strong>dr.sarah@mediverse.com</strong> / <strong>doctor123</strong>
          </p>
          <button
            onClick={handleDemoLogin}
            disabled={loading}
            className="mt-3 w-full py-2 bg-primary-600 hover:bg-primary-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <Sparkles className="w-3.5 h-3.5" />
            1-Click Demo Login as Dr. Sarah Jenkins (Cardiology)
          </button>
        </div>

        {/* Form Container */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-lg p-6 sm:p-8">
          
          {/* Switch tabs */}
          <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl mb-6">
            <button
              onClick={() => { setIsLogin(true); setError(''); }}
              className={`py-2 text-xs font-bold rounded-lg transition-all ${
                isLogin ? 'bg-white text-primary-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Doctor Log In
            </button>
            <button
              onClick={() => { setIsLogin(false); setError(''); }}
              className={`py-2 text-xs font-bold rounded-lg transition-all ${
                !isLogin ? 'bg-white text-primary-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Provider Registration
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name & Title</label>
                <div className="relative">
                  <Stethoscope className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Dr. Sarah Jenkins"
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Hospital / Clinic Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="doctor@hospital.org"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
            </div>

            {!isLogin && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Specialization</label>
                    <select
                      value={specialization}
                      onChange={(e) => setSpecialization(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      <option>Cardiology</option>
                      <option>Neurology</option>
                      <option>Dermatology</option>
                      <option>Pediatrics</option>
                      <option>General Medicine</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Years of Exp.</label>
                    <input
                      type="number"
                      value={experienceYears}
                      onChange={(e) => setExperienceYears(e.target.value)}
                      placeholder="e.g. 10"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Qualifications</label>
                    <input
                      type="text"
                      value={qualification}
                      onChange={(e) => setQualification(e.target.value)}
                      placeholder="MD, FACC, MBBS"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Fee ($ USD)</label>
                    <input
                      type="number"
                      value={consultationFee}
                      onChange={(e) => setConsultationFee(e.target.value)}
                      placeholder="50"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Affiliated Hospital / Practice</label>
                  <input
                    type="text"
                    value={hospital}
                    onChange={(e) => setHospital(e.target.value)}
                    placeholder="e.g. Metro Heart Institute"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-primary-600 hover:bg-primary-700 shadow-md transition-all flex items-center justify-center gap-2 mt-4"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>{isLogin ? 'Sign In as Doctor' : 'Register Medical Provider'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 text-center text-xs text-slate-500">
            Are you a patient?{' '}
            <button
              onClick={() => setActivePage('patient-login')}
              className="text-mediblue-700 font-semibold hover:underline"
            >
              Access Patient Portal
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
