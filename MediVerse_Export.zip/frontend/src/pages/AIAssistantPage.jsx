import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { 
  Bot, 
  Send, 
  AlertTriangle, 
  Sparkles, 
  User, 
  Stethoscope, 
  CheckCircle2, 
  HelpCircle, 
  RotateCcw, 
  ArrowRight,
  ShieldAlert,
  HeartPulse
} from 'lucide-react';

const QUICK_SYMPTOMS = [
  "Persistent dry cough & mild fever for 3 days",
  "Sharp lower back pain with morning stiffness",
  "Red itchy rash with small bumps on forearm",
  "Mild chest flutter and palpitations after running",
  "Severe throbbing headache on right side with nausea",
  "Child with 101°F fever and loss of appetite"
];

export default function AIAssistantPage({ setActivePage, setSelectedDoctorForBooking }) {
  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      message: "Hello! I am your **MediVerse AI Health Assistant**.\n\nYou can describe any physical symptoms, general health concerns, or ask for guidance on what specialist to see.\n\n*Please note: I provide preliminary triage and educational information, not clinical diagnoses.*",
      specialist_recommended: null,
      urgency_level: null,
      timestamp: "Just now"
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (messageText = null) => {
    const textToSend = messageText || input;
    if (!textToSend.trim() || loading) return;

    const userMessage = {
      sender: 'user',
      message: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    if (!messageText) setInput('');
    setLoading(true);

    try {
      const data = await api.sendAIChat(textToSend.trim());
      const aiMessage = {
        sender: 'ai',
        message: data.reply,
        specialist_recommended: data.details?.recommended_specialist,
        recommended_doctor_id: data.details?.recommended_doctor_id,
        urgency_level: data.details?.urgency_level,
        is_emergency: data.details?.is_emergency,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          sender: 'ai',
          message: "I am having difficulty connecting to the triage engine right now. However, if you are experiencing severe symptoms, please consult a physician or call emergency services immediately.",
          timestamp: "Just now"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleBookSpecialist = async (specialistName, docId) => {
    try {
      if (docId) {
        const doc = await api.getDoctorById(docId);
        setSelectedDoctorForBooking(doc);
      }
    } catch (e) {
      console.warn("Could not fetch specific doctor:", e);
    }
    setActivePage('appointment-booking');
  };

  const handleClear = () => {
    if (window.confirm("Start a fresh symptom assessment conversation?")) {
      setMessages([
        {
          sender: 'ai',
          message: "Welcome back. Describe your symptoms or healthcare query to begin.",
          specialist_recommended: null,
          urgency_level: null,
          timestamp: "Just now"
        }
      ]);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Title Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-100 text-primary-800 text-xs font-bold uppercase tracking-wider">
          <Bot className="w-4 h-4 text-primary-600" />
          <span>Intelligent Clinical Triage Engine</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          MediVerse AI Health Assistant
        </h1>
        <p className="text-sm text-slate-600 max-w-xl mx-auto">
          Preliminary symptom analysis, home comfort guidance, and direct specialist matching.
        </p>
      </div>

      {/* Mandatory Medical Disclaimer Banner */}
      <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-xl shadow-xs">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900 leading-relaxed">
            <strong className="font-bold">Medical Disclaimer:</strong> MediVerse AI provides preliminary healthcare information and triage guidance for educational purposes only. It is <strong>NOT</strong> a substitute for professional clinical diagnosis or emergency medical care. If you are experiencing chest pain, severe shortness of breath, sudden numbness, or life-threatening symptoms, call <strong>911 / 112</strong> immediately.
          </div>
        </div>
      </div>

      {/* Quick Prompts Carousel / Pills */}
      <div className="space-y-1.5">
        <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-primary-600" />
          Try Asking About Common Symptoms:
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {QUICK_SYMPTOMS.map((symptom, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(symptom)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-primary-50 hover:border-primary-300 text-xs text-slate-700 font-medium whitespace-nowrap transition-colors shrink-0 shadow-xs"
            >
              {symptom}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-lg flex flex-col h-[560px] overflow-hidden">
        
        {/* Chat Header */}
        <div className="px-6 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary-600 text-white flex items-center justify-center font-bold text-xs">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">MediVerse AI Triage Bot</div>
              <div className="text-[10px] text-emerald-600 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Online & Ready
              </div>
            </div>
          </div>

          <button
            onClick={handleClear}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1"
            title="Start new conversation"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Chat
          </button>
        </div>

        {/* Message History Feed */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center shrink-0 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-mediblue-600 text-white rounded-br-xs shadow-sm'
                    : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-bl-xs shadow-xs space-y-3'
                }`}
              >
                {/* Emergency Tag */}
                {msg.is_emergency && (
                  <div className="p-2 rounded-lg bg-rose-100 text-rose-900 font-bold text-xs flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>EMERGENCY ALERT: Immediate Clinical Evaluation Advised</span>
                  </div>
                )}

                {/* Urgency Badge */}
                {msg.urgency_level && (
                  <div className="inline-block px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary-100 text-primary-800 border border-primary-200">
                    Urgency: {msg.urgency_level}
                  </div>
                )}

                {/* Body Content */}
                <div className="whitespace-pre-line">
                  {msg.message}
                </div>

                {/* Recommended Specialist Action Card */}
                {msg.specialist_recommended && (
                  <div className="mt-3 p-3 bg-white rounded-xl border border-mediblue-200 shadow-xs flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-mediblue-100 text-mediblue-700 flex items-center justify-center shrink-0">
                        <Stethoscope className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-500 font-medium">Recommended Care</div>
                        <div className="font-bold text-slate-900 text-xs">Consult a {msg.specialist_recommended}</div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleBookSpecialist(msg.specialist_recommended, msg.recommended_doctor_id)}
                      className="px-3 py-1.5 bg-mediblue-600 hover:bg-mediblue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <span>Book Doctor</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                <div className={`text-[10px] mt-1 ${msg.sender === 'user' ? 'text-mediblue-200 text-right' : 'text-slate-400'}`}>
                  {msg.timestamp}
                </div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-mediblue-100 text-mediblue-700 flex items-center justify-center shrink-0 mt-1 font-bold text-xs">
                  U
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 items-center">
              <div className="w-8 h-8 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 text-xs text-slate-500 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary-500 animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-primary-500 animate-bounce delay-100"></div>
                <div className="w-2 h-2 rounded-full bg-primary-500 animate-bounce delay-200"></div>
                <span className="font-medium text-slate-600">Analyzing symptoms & medical triage rules...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="p-4 bg-slate-50 border-t border-slate-200 flex items-center gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your symptoms, duration, or general health question here..."
            className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500 text-xs sm:text-sm bg-white"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-primary-600 to-mediblue-600 hover:from-primary-700 hover:to-mediblue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
          >
            <span>Ask AI</span>
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>

    </div>
  );
}
