import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  User, 
  Calendar, 
  Video, 
  Bot, 
  FileText, 
  Search, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  Heart, 
  ShieldAlert, 
  Plus, 
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Sparkles
} from 'lucide-react';

export default function PatientDashboardPage({ setActivePage, setConsultationRoomId, setSelectedDoctorForBooking }) {
  const { user, profile, logout } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState(null);

  useEffect(() => {
    async function loadDashboard() {
      try {
        setLoading(true);
        const [apps, recs] = await Promise.all([
          api.getAppointments(),
          api.getMedicalRecords()
        ]);
        setAppointments(apps);
        setRecords(recs.slice(0, 3));
      } catch (err) {
        console.error("Dashboard data fetch error:", err);
      } finally {
        setLoading(false);
      }
    }
    loadDashboard();
  }, []);

  const handleJoinCall = (room) => {
    setConsultationRoomId(room);
    setActivePage('telemedicine');
  };

  const handleCancelAppointment = async (id) => {
    if (!window.confirm("Are you sure you want to cancel this appointment?")) return;
    try {
      setCancellingId(id);
      await api.updateAppointment(id, { status: 'Cancelled' });
      setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: 'Cancelled' } : a));
    } catch (err) {
      alert("Error cancelling appointment: " + err.message);
    } finally {
      setCancellingId(null);
    }
  };

  const upcomingAppointments = appointments.filter(a => a.status === 'Upcoming');
  const pastAppointments = appointments.filter(a => a.status !== 'Upcoming');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-mediblue-700 via-mediblue-600 to-primary-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-xs font-semibold text-white backdrop-blur-xs">
              <User className="w-3.5 h-3.5" />
              <span>Verified Patient Account</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.name || 'Patient'}!
            </h1>
            <p className="text-mediblue-100 text-sm max-w-xl">
              Manage your upcoming video consultations, access digital health records, and check symptoms with MediVerse AI.
            </p>

            {/* Quick Health Vitals Tags */}
            <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
              <span className="px-2.5 py-1 bg-white/15 rounded-lg border border-white/20">
                Blood Group: <strong>{profile?.blood_group || 'O+'}</strong>
              </span>
              <span className="px-2.5 py-1 bg-white/15 rounded-lg border border-white/20">
                Age: <strong>{profile?.age || '38'} yrs</strong>
              </span>
              <span className="px-2.5 py-1 bg-white/15 rounded-lg border border-white/20">
                Allergies: <strong>{profile?.allergies || 'None reported'}</strong>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-3 shrink-0">
            <button
              onClick={() => setActivePage('doctor-search')}
              className="px-4 py-2.5 bg-white text-mediblue-800 hover:bg-slate-100 font-bold rounded-xl text-xs sm:text-sm shadow-md transition-colors flex items-center gap-2"
            >
              <Search className="w-4 h-4 text-mediblue-600" />
              Find Doctors
            </button>
            <button
              onClick={() => setActivePage('ai-assistant')}
              className="px-4 py-2.5 bg-primary-400 hover:bg-primary-300 text-slate-900 font-bold rounded-xl text-xs sm:text-sm shadow-md transition-colors flex items-center gap-2"
            >
              <Bot className="w-4 h-4" />
              Ask AI Triage
            </button>
          </div>
        </div>
      </div>

      {/* Quick Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Upcoming Visits</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">{upcomingAppointments.length}</div>
            <div className="text-[11px] text-mediblue-600 mt-1">Telemedicine sessions</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-mediblue-50 text-mediblue-600 flex items-center justify-center">
            <Video className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Health Records</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">{records.length}</div>
            <div className="text-[11px] text-primary-600 mt-1">Prescriptions & Labs</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">AI Symptom Checks</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">Active</div>
            <div className="text-[11px] text-teal-600 mt-1">24/7 Available</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <Bot className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Medical Status</div>
            <div className="text-lg font-bold text-emerald-600 mt-1">Up to Date</div>
            <div className="text-[11px] text-slate-500 mt-1">Annual vitals normal</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Content Grid: Upcoming Appointments + Shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Upcoming Appointments (2 Cols) */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-mediblue-100 text-mediblue-700 flex items-center justify-center">
                  <Calendar className="w-4 h-4" />
                </div>
                <h2 className="text-lg font-bold text-slate-900">Upcoming Consultations</h2>
              </div>
              <button
                onClick={() => setActivePage('doctor-search')}
                className="text-xs font-semibold text-mediblue-600 hover:text-mediblue-700 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Book New
              </button>
            </div>

            {loading ? (
              <div className="py-12 text-center text-slate-400">Loading appointments...</div>
            ) : upcomingAppointments.length === 0 ? (
              <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-200 p-6">
                <Calendar className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700">No upcoming consultations</p>
                <p className="text-xs text-slate-500 mt-1">Book an appointment with one of our specialized doctors.</p>
                <button
                  onClick={() => setActivePage('doctor-search')}
                  className="mt-4 px-4 py-2 bg-mediblue-600 text-white text-xs font-semibold rounded-lg shadow-sm hover:bg-mediblue-700 transition-colors"
                >
                  Find a Doctor
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {upcomingAppointments.map((app) => (
                  <div
                    key={app.id}
                    className="p-5 rounded-2xl border border-mediblue-100 bg-gradient-to-r from-mediblue-50/40 to-white hover:border-mediblue-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-mediblue-100 text-mediblue-800 flex items-center justify-center font-bold text-base shrink-0">
                        {app.doctor_avatar ? (
                          <img src={app.doctor_avatar} alt={app.doctor_name} className="w-12 h-12 rounded-xl object-cover" />
                        ) : (
                          app.doctor_name.charAt(0)
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-slate-900">{app.doctor_name}</h3>
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-primary-100 text-primary-800">
                            {app.doctor_specialization}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            {app.appointment_date}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1 font-semibold text-slate-700">
                            <Clock className="w-3.5 h-3.5 text-mediblue-600" />
                            {app.appointment_time}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-2 bg-white/80 p-2 rounded-lg border border-slate-100 max-w-md">
                          <strong>Reason:</strong> {app.reason || 'General Tele-Consultation'}
                        </p>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleJoinCall(app.meeting_room_id)}
                        className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-mediblue-600 to-primary-600 hover:from-mediblue-700 hover:to-primary-700 text-white font-bold text-xs rounded-xl shadow-sm flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Video className="w-3.5 h-3.5" />
                        Join Video Call
                      </button>
                      <button
                        onClick={() => handleCancelAppointment(app.id)}
                        disabled={cancellingId === app.id}
                        className="w-full sm:w-auto px-3 py-1.5 text-rose-600 hover:bg-rose-50 rounded-lg text-xs font-semibold transition-colors text-center"
                      >
                        {cancellingId === app.id ? 'Cancelling...' : 'Cancel'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Past Consultation History */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              Consultation History
            </h2>

            {pastAppointments.length === 0 ? (
              <p className="text-xs text-slate-500">No past consultations recorded.</p>
            ) : (
              <div className="divide-y divide-slate-100">
                {pastAppointments.map((app) => (
                  <div key={app.id} className="py-3.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-slate-800">{app.doctor_name} ({app.doctor_specialization})</div>
                      <div className="text-slate-500 mt-0.5">{app.appointment_date} at {app.appointment_time}</div>
                      {app.prescription && (
                        <div className="text-primary-700 font-medium mt-1">Rx: {app.prescription}</div>
                      )}
                    </div>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      app.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {app.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Right Column: AI Assistant Shortcut + Health Records Preview (1 Col) */}
        <div className="space-y-6">
          
          {/* AI Assistant Quick Card */}
          <div className="bg-gradient-to-br from-primary-900 via-primary-800 to-mediblue-900 rounded-3xl p-6 text-white shadow-md relative overflow-hidden">
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white">
                <Bot className="w-5 h-5 text-primary-300" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-primary-300">
                AI Health Triage
              </span>
            </div>

            <h3 className="text-xl font-bold">Unsure about symptoms?</h3>
            <p className="text-xs text-primary-100 mt-1.5 leading-relaxed">
              Describe your discomfort in plain words. MediVerse AI analyzes urgency, offers comfort steps, and matches you to the right specialist.
            </p>

            <button
              onClick={() => setActivePage('ai-assistant')}
              className="mt-5 w-full py-2.5 bg-primary-400 hover:bg-primary-300 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
            >
              <span>Ask MediVerse AI Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Health Records Preview */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-mediblue-600" />
                <h3 className="font-bold text-slate-900 text-base">Recent Records</h3>
              </div>
              <button
                onClick={() => setActivePage('digital-records')}
                className="text-xs font-semibold text-mediblue-600 hover:underline"
              >
                View All
              </button>
            </div>

            {records.length === 0 ? (
              <p className="text-xs text-slate-400">No health records uploaded yet.</p>
            ) : (
              <div className="space-y-3">
                {records.map((r) => (
                  <div 
                    key={r.id} 
                    onClick={() => setActivePage('digital-records')}
                    className="p-3 rounded-xl border border-slate-100 bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 truncate">{r.title}</span>
                      <span className="text-[10px] font-bold text-slate-500 uppercase px-1.5 py-0.5 bg-white rounded border border-slate-200">
                        {r.record_type}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                      <span>{r.doctor_name || 'Self Reported'}</span>
                      <span>{r.record_date}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={() => setActivePage('digital-records')}
              className="w-full py-2 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors text-center"
            >
              Manage Digital Health Vault
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
