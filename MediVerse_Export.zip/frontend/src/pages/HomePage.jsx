import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  HeartPulse, 
  Bot, 
  Video, 
  Calendar, 
  ShieldCheck, 
  Clock, 
  Users, 
  Star, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles, 
  Activity, 
  Stethoscope, 
  MapPin, 
  ChevronRight,
  Zap,
  Globe2
} from 'lucide-react';

export default function HomePage({ setActivePage, setSelectedDoctorForBooking }) {
  const { user, quickLogin } = useAuth();
  const [featuredDoctors, setFeaturedDoctors] = useState([]);
  const [specializations, setSpecializations] = useState([]);

  useEffect(() => {
    async function loadData() {
      try {
        const docs = await api.getDoctors();
        setFeaturedDoctors(docs.slice(0, 4));
        const specs = await api.getSpecializations();
        setSpecializations(specs);
      } catch (err) {
        console.error("Failed to load home page data:", err);
      }
    }
    loadData();
  }, []);

  const handleBookDoctor = (doc) => {
    setSelectedDoctorForBooking(doc);
    setActivePage('appointment-booking');
  };

  const handleQuickLogin = async (role) => {
    try {
      await quickLogin(role);
      setActivePage(role === 'patient' ? 'patient-dashboard' : 'doctor-dashboard');
    } catch (err) {
      alert("Demo login error: " + err.message);
    }
  };

  return (
    <div className="space-y-20 pb-20">
      
      {/* Hero Banner Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-mediblue-50/80 via-white to-slate-50 pt-12 pb-20 border-b border-slate-200">
        <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 bg-primary-200/40 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 bg-mediblue-200/40 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Tagline Badge */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-mediblue-200 shadow-sm text-xs font-semibold text-mediblue-800">
              <span className="flex h-2 w-2 rounded-full bg-primary-500 animate-pulse"></span>
              <span>Next-Gen Healthcare Technology</span>
              <span className="text-slate-300">|</span>
              <span className="text-primary-700">Connecting People to Better Healthcare</span>
            </div>
          </div>

          {/* Main Hero Header */}
          <div className="text-center max-w-4xl mx-auto space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Your Health, Our Priority – <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-mediblue-600 via-primary-600 to-teal-500 bg-clip-text text-transparent">
                Healthcare Anytime, Anywhere.
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-slate-600 leading-relaxed font-normal max-w-3xl mx-auto">
              MediVerse connects patients and specialized doctors through instantaneous <strong>online video consultations</strong> and <strong>AI-assisted preliminary triage</strong>. Delivering equitable medical care to urban households and underserved rural communities alike.
            </p>

            {/* Call to Actions */}
            <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => setActivePage('doctor-search')}
                className="px-6 py-3.5 rounded-xl font-semibold text-white bg-mediblue-600 hover:bg-mediblue-700 shadow-lg shadow-mediblue-500/25 flex items-center gap-2.5 transition-all transform hover:-translate-y-0.5"
              >
                <Video className="w-5 h-5" />
                Consult a Doctor Online
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActivePage('ai-assistant')}
                className="px-6 py-3.5 rounded-xl font-semibold text-primary-800 bg-primary-100 hover:bg-primary-200 border border-primary-300 flex items-center gap-2.5 transition-all transform hover:-translate-y-0.5"
              >
                <Bot className="w-5 h-5 text-primary-700" />
                Ask AI Health Assistant
                <span className="px-1.5 py-0.5 text-[10px] bg-primary-600 text-white rounded font-bold">24/7 Free</span>
              </button>
            </div>

            {/* Quick Demo Access Bar */}
            <div className="pt-8">
              <div className="inline-block bg-white/80 backdrop-blur-md border border-amber-200 rounded-2xl p-4 shadow-sm max-w-xl mx-auto text-left">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-800 mb-2">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  College Project Reviewer Demo Credentials (1-Click Login):
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    onClick={() => handleQuickLogin('patient')}
                    className="p-2.5 rounded-lg border border-mediblue-200 bg-mediblue-50 hover:bg-mediblue-100 text-left transition-colors flex items-center gap-2.5"
                  >
                    <div className="w-8 h-8 rounded-full bg-mediblue-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      P
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-bold text-slate-800">Login as Patient (John Doe)</div>
                      <div className="text-[11px] text-slate-500">patient@mediverse.com</div>
                    </div>
                  </button>

                  <button
                    onClick={() => handleQuickLogin('doctor')}
                    className="p-2.5 rounded-lg border border-primary-200 bg-primary-50 hover:bg-primary-100 text-left transition-colors flex items-center gap-2.5"
                  >
                    <div className="w-8 h-8 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                      Dr
                    </div>
                    <div className="truncate">
                      <div className="text-xs font-bold text-slate-800">Login as Doctor (Dr. Sarah)</div>
                      <div className="text-[11px] text-slate-500">dr.sarah@mediverse.com</div>
                    </div>
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* Quick Metrics Strip */}
          <div className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-mediblue-100 text-mediblue-600 flex items-center justify-center shrink-0">
                <Video className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">50,000+</div>
                <div className="text-xs text-slate-500 font-medium">Remote Consultations</div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center shrink-0">
                <Stethoscope className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">150+</div>
                <div className="text-xs text-slate-500 font-medium">Verified Specialists</div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                <Star className="w-6 h-6 fill-amber-500 text-amber-500" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">4.9 / 5.0</div>
                <div className="text-xs text-slate-500 font-medium">Patient Satisfaction</div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                <Zap className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-900">Instant</div>
                <div className="text-xs text-slate-500 font-medium">24/7 AI Health Triage</div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Two Core Pillars Section: Telemedicine & AI Health Assistant */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-primary-700 bg-primary-100 px-3 py-1 rounded-full inline-block">
            Core Focus Areas
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-slate-900">
            Two Pillars of Modern Digital Care
          </h3>
          <p className="text-slate-600 text-base">
            MediVerse specializes strictly in high-reliability <strong>Telemedicine</strong> and <strong>AI-Powered Preliminary Assistance</strong> without unnecessary complexity.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Pillar 1: Telemedicine */}
          <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-md hover:shadow-xl transition-shadow relative overflow-hidden flex flex-col justify-between">
            <div className="space-y-5">
              <div className="w-14 h-14 rounded-2xl bg-mediblue-100 text-mediblue-700 flex items-center justify-center">
                <Video className="w-7 h-7" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-mediblue-600">Feature #1</span>
                <h4 className="text-2xl font-bold text-slate-900 mt-1">
                  Online Telemedicine Consultations
                </h4>
                <p className="text-slate-600 text-sm mt-2 leading-relaxed">
                  Connect face-to-face with certified cardiologists, dermatologists, pediatricians, and internal medicine physicians using WebRTC video streaming.
                </p>
              </div>

              <ul className="space-y-3 text-sm text-slate-700 pt-2">
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Real-time audio & video consultation room with camera, mic, and screen share controls.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Interactive doctor prescription drafting pad and in-call live chat.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Instant appointment booking with conflict checking and reminder management.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Clearly labeled simulation mode for demonstrations without live peer hardware.</span>
                </li>
              </ul>
            </div>

            <div className="pt-8">
              <button
                onClick={() => setActivePage('doctor-search')}
                className="w-full py-3 bg-mediblue-50 hover:bg-mediblue-100 text-mediblue-700 font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors border border-mediblue-200"
              >
                <span>Find & Book a Specialist</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Pillar 2: AI Health Assistant */}
          <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-md hover:shadow-xl transition-shadow relative overflow-hidden flex flex-col justify-between">
            <div className="space-y-5">
              <div className="w-14 h-14 rounded-2xl bg-primary-100 text-primary-700 flex items-center justify-center">
                <Bot className="w-7 h-7" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-primary-600">Feature #2</span>
                <h4 className="text-2xl font-bold text-slate-900 mt-1">
                  AI-Powered Health Assistant
                </h4>
                <p className="text-slate-600 text-sm mt-2 leading-relaxed">
                  Intelligent conversational clinical triage that evaluates symptoms, flags emergencies, provides at-home comfort measures, and suggests the exact doctor specialization to consult.
                </p>
              </div>

              <ul className="space-y-3 text-sm text-slate-700 pt-2">
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>24/7 symptom analysis with structured urgency assessment (Mild / Moderate / Urgent / ER).</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Direct recommendation of doctors with 1-click booking triggers.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Prominent medical disclaimer ensuring safe educational guidance.</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary-600 shrink-0" />
                  <span>Smart fallback triage engine that operates smoothly even when external AI APIs are offline.</span>
                </li>
              </ul>
            </div>

            <div className="pt-8">
              <button
                onClick={() => setActivePage('ai-assistant')}
                className="w-full py-3 bg-primary-50 hover:bg-primary-100 text-primary-800 font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors border border-primary-200"
              >
                <span>Launch AI Health Assistant</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* Featured Doctors Section */}
      <section className="bg-white py-16 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-mediblue-600 bg-mediblue-50 px-3 py-1 rounded-full">
                Board-Certified Doctors
              </span>
              <h3 className="text-3xl font-extrabold text-slate-900 mt-2">
                Consult Top Medical Specialists
              </h3>
              <p className="text-slate-600 text-sm mt-1">
                Verified physicians available for same-day video consultations.
              </p>
            </div>

            <button
              onClick={() => setActivePage('doctor-search')}
              className="text-sm font-semibold text-mediblue-600 hover:text-mediblue-700 flex items-center gap-1.5 self-start md:self-auto"
            >
              <span>View all specialists</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredDoctors.map((doc) => (
              <div 
                key={doc.id}
                className="bg-slate-50 rounded-2xl border border-slate-200 p-5 hover:border-mediblue-300 hover:shadow-lg transition-all flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="relative">
                    <img 
                      src={doc.avatar_url} 
                      alt={doc.name} 
                      className="w-full h-44 object-cover rounded-xl"
                    />
                    <span className="absolute top-2.5 right-2.5 bg-white/95 backdrop-blur-xs px-2 py-1 rounded-md text-xs font-bold text-slate-800 flex items-center gap-1 shadow-xs">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      {doc.rating}
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-primary-700 bg-primary-100 px-2 py-0.5 rounded">
                      {doc.specialization}
                    </span>
                    <h4 className="text-lg font-bold text-slate-900 mt-1">{doc.name}</h4>
                    <p className="text-xs text-slate-500 font-medium truncate">{doc.hospital}</p>
                    <p className="text-xs text-slate-600 mt-2 line-clamp-2">{doc.bio}</p>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-500">Consultation Fee</span>
                    <div className="text-base font-bold text-slate-900">${doc.consultation_fee}</div>
                  </div>
                  <button
                    onClick={() => handleBookDoctor(doc)}
                    className="px-3.5 py-2 bg-mediblue-600 hover:bg-mediblue-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
                  >
                    Book Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How MediVerse Works: 4 Steps */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <h2 className="text-xs font-bold uppercase tracking-wider text-primary-700 bg-primary-100 px-3 py-1 rounded-full inline-block">
            Simple Process
          </h2>
          <h3 className="text-3xl font-extrabold text-slate-900">
            How MediVerse Works in 4 Simple Steps
          </h3>
          <p className="text-slate-600 text-sm">
            Accessible from any mobile phone, tablet, or computer without installing heavy apps.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 relative">
            <span className="text-3xl font-black text-mediblue-200">01</span>
            <h4 className="text-lg font-bold text-slate-900 mt-2">Describe Symptoms</h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Use our AI Health Assistant for instant triage, comfort advice, and recommended specialty matching.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 relative">
            <span className="text-3xl font-black text-primary-200">02</span>
            <h4 className="text-lg font-bold text-slate-900 mt-2">Choose Doctor</h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Browse doctor profiles, credentials, ratings, and pick a convenient consultation time slot.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 relative">
            <span className="text-3xl font-black text-teal-200">03</span>
            <h4 className="text-lg font-bold text-slate-900 mt-2">Video Consultation</h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Join the secure WebRTC video room from home with high-definition audio, video, and live chat.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 relative">
            <span className="text-3xl font-black text-medigreen-300">04</span>
            <h4 className="text-lg font-bold text-slate-900 mt-2">Digital Records</h4>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              Access your digital prescription, clinical notes, and follow-up guidance in your secure portal anytime.
            </p>
          </div>
        </div>
      </section>

      {/* Underserved & Rural Community Impact Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-mediblue-900 via-mediblue-800 to-primary-900 text-white rounded-3xl p-8 sm:p-12 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-primary-300">
              <Globe2 className="w-3.5 h-3.5" />
              Equitable Healthcare Accessibility
            </div>
            <h3 className="text-3xl sm:text-4xl font-extrabold leading-tight">
              Bridging the Distance to Medical Specialists for Rural Families
            </h3>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Over 40% of rural patients travel more than 50 miles to reach a certified medical specialist. MediVerse eliminates geographical barriers with bandwidth-optimized video consultations and intelligent AI pre-triage.
            </p>
          </div>

          <div className="shrink-0 flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
            <button
              onClick={() => setActivePage('doctor-search')}
              className="px-6 py-3.5 bg-primary-500 hover:bg-primary-600 text-slate-950 font-bold rounded-xl transition-colors text-center"
            >
              Book Telemedicine Visit
            </button>
            <button
              onClick={() => setActivePage('about')}
              className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl border border-white/20 transition-colors text-center"
            >
              Learn Our Mission
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
