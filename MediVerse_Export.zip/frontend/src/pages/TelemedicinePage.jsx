import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  PhoneOff, 
  Share2, 
  MessageSquare, 
  FileText, 
  User, 
  ShieldCheck, 
  Clock, 
  Sparkles, 
  Send, 
  Pill, 
  Check, 
  Volume2, 
  Maximize2,
  AlertCircle
} from 'lucide-react';

export default function TelemedicinePage({ 
  setActivePage, 
  consultationRoomId = 'room-mediverse-101' 
}) {
  const { user, profile } = useAuth();
  const [roomId, setRoomId] = useState(consultationRoomId || 'room-mediverse-101');
  const [micEnabled, setMicEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [screenSharing, setScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState(145); // Seconds elapsed
  const [activeTab, setActiveTab] = useState('chat'); // 'chat', 'rx', 'brief'
  
  // Chat state
  const [chatMessages, setChatMessages] = useState([
    { sender_name: "Dr. Sarah Jenkins", sender_role: "doctor", text: "Hello! Can you hear and see me clearly?", timestamp: "10:30 AM" },
    { sender_name: "John Doe", sender_role: "patient", text: "Yes doctor, loud and clear. Thank you for connecting so promptly.", timestamp: "10:31 AM" },
    { sender_name: "Dr. Sarah Jenkins", sender_role: "doctor", text: "Let's review the symptoms you noted about the mild palpitations after exertion.", timestamp: "10:31 AM" }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  
  // Real camera stream reference
  const localVideoRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState(null);

  // Prescription in-call state
  const [inCallRxNotes, setInCallRxNotes] = useState('');
  const [inCallMedication, setInCallMedication] = useState('');
  const [rxIssued, setRxIssued] = useState(false);

  // Call timer interval
  useEffect(() => {
    const timer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Attempt WebRTC camera stream
  useEffect(() => {
    let streamInstance = null;
    async function startCamera() {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
          streamInstance = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
          setCameraActive(true);
        } catch (err) {
          console.warn("Camera not available or blocked in current sandbox:", err.message);
          setCameraError(err.message);
          setCameraActive(false);
        }
      }
    }
    startCamera();

    return () => {
      if (streamInstance) {
        streamInstance.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const formatTimer = (totalSeconds) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMsg = {
      sender_name: user?.name || "Participant",
      sender_role: user?.role || "patient",
      text: inputMessage.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, newMsg]);
    setInputMessage('');

    // Simulate doctor response if patient talks
    if (user?.role === 'patient') {
      setTimeout(() => {
        setChatMessages(prev => [
          ...prev,
          {
            sender_name: "Dr. Sarah Jenkins",
            sender_role: "doctor",
            text: "I am documenting your response into the clinical notes. Everything looks under control.",
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }, 1500);
    }
  };

  const handleIssueInCallRx = (e) => {
    e.preventDefault();
    setRxIssued(true);
    setChatMessages(prev => [
      ...prev,
      {
        sender_name: "MediVerse System",
        sender_role: "system",
        text: `Prescription issued: ${inCallMedication}. It has been saved directly to patient's Digital Health Records.`,
        timestamp: "Just now"
      }
    ]);
  };

  const handleEndCall = () => {
    if (window.confirm("Are you sure you want to conclude this telemedicine consultation?")) {
      if (user?.role === 'doctor') {
        setActivePage('doctor-dashboard');
      } else {
        setActivePage('patient-dashboard');
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Consultation Header */}
      <div className="bg-white rounded-2xl border border-slate-200 px-6 py-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <Video className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-slate-900 text-lg">Telemedicine Consultation Suite</h1>
              <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                LIVE HD CALL
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Room ID: <span className="font-mono font-semibold text-slate-700">{roomId}</span> • Peer-to-Peer WebRTC Protocol
            </p>
          </div>
        </div>

        {/* Demo Mode & Security Badges */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-semibold">
            <Clock className="w-4 h-4 text-mediblue-600" />
            <span>Call Time: <strong className="font-mono text-slate-900">{formatTimer(callDuration)}</strong></span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-mediblue-50 text-mediblue-800 text-xs font-semibold border border-mediblue-200">
            <ShieldCheck className="w-4 h-4 text-mediblue-600" />
            <span>256-bit Encrypted</span>
          </div>
        </div>
      </div>

      {/* Main Video Call & Side Panel Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Video Consultation Display (2 Columns) */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="relative bg-slate-950 rounded-3xl overflow-hidden aspect-video shadow-2xl border border-slate-800 flex items-center justify-center">
            
            {/* Primary Remote Video (Doctor or Patient) */}
            <div className="absolute inset-0 w-full h-full">
              <img
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=1200"
                alt="Doctor remote stream"
                className="w-full h-full object-cover brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30"></div>
            </div>

            {/* Remote Participant Label */}
            <div className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-white text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-bold">
                {user?.role === 'doctor' ? 'Patient: John Doe' : 'Dr. Sarah Jenkins (Cardiologist)'}
              </span>
              <span className="text-[10px] text-slate-400">1080p HD</span>
            </div>

            {/* WebRTC / Demo Mode indicator banner overlay */}
            <div className="absolute top-4 right-4 z-20 bg-amber-500/90 text-slate-950 px-3 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-wider backdrop-blur-xs shadow-md">
              Demo Mode Active: WebRTC Media & Peer Simulation Enabled
            </div>

            {/* Audio Wave animation representation */}
            <div className="absolute bottom-6 left-6 z-20 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl text-white text-xs">
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <div className="flex items-center gap-0.5 h-3">
                <span className="w-1 h-3 bg-emerald-400 rounded-full animate-bounce"></span>
                <span className="w-1 h-2 bg-emerald-400 rounded-full animate-bounce delay-75"></span>
                <span className="w-1 h-4 bg-emerald-400 rounded-full animate-bounce delay-150"></span>
                <span className="w-1 h-2 bg-emerald-400 rounded-full animate-bounce"></span>
              </div>
              <span className="text-[11px] text-slate-300 ml-1">Audio Transmitting</span>
            </div>

            {/* Local Video Inset (Picture-in-Picture) */}
            <div className="absolute bottom-6 right-6 z-20 w-36 sm:w-48 aspect-video bg-slate-900 rounded-2xl overflow-hidden border-2 border-white/20 shadow-xl">
              {videoEnabled ? (
                cameraActive ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                ) : (
                  <div className="w-full h-full relative">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400"
                      alt="Local user feed"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-1 right-2 text-[9px] text-white/90 bg-black/60 px-1 rounded">
                      Local Mirror
                    </div>
                  </div>
                )
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-slate-800 text-slate-400 text-xs">
                  <VideoOff className="w-5 h-5 mb-1 text-slate-500" />
                  <span>Camera Off</span>
                </div>
              )}
              <div className="absolute top-1 left-2 text-[9px] font-bold text-white bg-slate-900/80 px-1.5 py-0.5 rounded">
                You ({user?.name ? user.name.split(' ')[0] : 'Self'})
              </div>
            </div>

          </div>

          {/* Interactive WebRTC Call Controls Bar */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            
            {/* Mic Toggle */}
            <button
              onClick={() => setMicEnabled(!micEnabled)}
              className={`p-3.5 rounded-2xl font-semibold text-xs transition-all flex items-center gap-2 ${
                micEnabled 
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                  : 'bg-rose-100 hover:bg-rose-200 text-rose-700'
              }`}
              title={micEnabled ? "Mute Microphone" : "Unmute Microphone"}
            >
              {micEnabled ? <Mic className="w-5 h-5 text-slate-700" /> : <MicOff className="w-5 h-5 text-rose-600" />}
              <span className="hidden sm:inline">{micEnabled ? 'Mute' : 'Unmuted'}</span>
            </button>

            {/* Video Camera Toggle */}
            <button
              onClick={() => setVideoEnabled(!videoEnabled)}
              className={`p-3.5 rounded-2xl font-semibold text-xs transition-all flex items-center gap-2 ${
                videoEnabled 
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800' 
                  : 'bg-rose-100 hover:bg-rose-200 text-rose-700'
              }`}
              title={videoEnabled ? "Turn Off Camera" : "Turn On Camera"}
            >
              {videoEnabled ? <Video className="w-5 h-5 text-slate-700" /> : <VideoOff className="w-5 h-5 text-rose-600" />}
              <span className="hidden sm:inline">{videoEnabled ? 'Stop Video' : 'Start Video'}</span>
            </button>

            {/* Screen Share Toggle */}
            <button
              onClick={() => {
                setScreenSharing(!screenSharing);
                alert(screenSharing ? "Screen sharing ended." : "Screen sharing requested. WebRTC display stream initialized.");
              }}
              className={`p-3.5 rounded-2xl font-semibold text-xs transition-all flex items-center gap-2 ${
                screenSharing 
                  ? 'bg-primary-100 text-primary-800' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
              title="Share Screen"
            >
              <Share2 className="w-5 h-5" />
              <span className="hidden sm:inline">Share Screen</span>
            </button>

            {/* End Call Button */}
            <button
              onClick={handleEndCall}
              className="px-6 py-3.5 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-bold text-xs shadow-md shadow-rose-600/25 flex items-center gap-2 transition-all"
            >
              <PhoneOff className="w-5 h-5" />
              <span>Conclude Call</span>
            </button>

          </div>

        </div>

        {/* In-Call Side Panel: Chat, Prescription Pad & Patient Brief (1 Column) */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col h-[520px] overflow-hidden">
          
          {/* Side Tabs */}
          <div className="grid grid-cols-3 border-b border-slate-200 bg-slate-50/80 p-1.5 text-xs font-bold text-slate-600">
            <button
              onClick={() => setActiveTab('chat')}
              className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'chat' ? 'bg-white text-mediblue-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Chat</span>
            </button>
            <button
              onClick={() => setActiveTab('rx')}
              className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'rx' ? 'bg-white text-mediblue-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              <Pill className="w-3.5 h-3.5" />
              <span>Rx Pad</span>
            </button>
            <button
              onClick={() => setActiveTab('brief')}
              className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'brief' ? 'bg-white text-mediblue-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Brief</span>
            </button>
          </div>

          {/* TAB 1: Real-time In-Call Chat */}
          {activeTab === 'chat' && (
            <div className="flex-1 flex flex-col justify-between overflow-hidden p-4">
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${
                      msg.sender_name === user?.name ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-0.5">
                      <span className="font-semibold text-slate-700">{msg.sender_name}</span>
                      <span>•</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <div
                      className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 leading-relaxed ${
                        msg.sender_role === 'system'
                          ? 'bg-amber-50 border border-amber-200 text-amber-900 font-semibold text-center'
                          : msg.sender_name === user?.name
                          ? 'bg-mediblue-600 text-white rounded-br-xs'
                          : 'bg-slate-100 text-slate-800 rounded-bl-xs'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleSendMessage} className="pt-3 border-t border-slate-100 flex items-center gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Type an instant message..."
                  className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
                />
                <button
                  type="submit"
                  className="p-2.5 rounded-xl bg-mediblue-600 hover:bg-mediblue-700 text-white transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: Doctor Prescription Pad */}
          {activeTab === 'rx' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-primary-700 bg-primary-100 px-2 py-0.5 rounded">
                  Electronic Prescription Pad
                </span>
                <h3 className="font-bold text-slate-900 text-sm mt-1">Issue Digital Prescription</h3>
                <p className="text-slate-500 text-[11px]">
                  Prescriptions issued during the call automatically synchronize with the patient's Digital Health Records.
                </p>
              </div>

              {rxIssued ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2">
                  <Check className="w-8 h-8 text-emerald-600 mx-auto" />
                  <div className="font-bold text-emerald-900 text-sm">Prescription Issued Successfully</div>
                  <p className="text-emerald-700 text-xs">
                    Prescribed: <strong>{inCallMedication}</strong>
                  </p>
                  <button
                    onClick={() => setRxIssued(false)}
                    className="text-xs text-primary-700 font-bold hover:underline"
                  >
                    Issue Another Prescription
                  </button>
                </div>
              ) : (
                <form onSubmit={handleIssueInCallRx} className="space-y-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Diagnosis / Assessment</label>
                    <input
                      type="text"
                      required
                      value={inCallRxNotes}
                      onChange={(e) => setInCallRxNotes(e.target.value)}
                      placeholder="e.g. Mild Benign Sinus Arrhythmia"
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Medication & Regimen</label>
                    <textarea
                      rows="3"
                      required
                      value={inCallMedication}
                      onChange={(e) => setInCallMedication(e.target.value)}
                      placeholder="e.g. Propranolol 20mg once daily in morning for 14 days after meal."
                      className="w-full p-2 rounded-lg border border-slate-300 text-xs"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl shadow-xs transition-colors"
                  >
                    Digitally Sign & Issue Rx
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 3: Patient Clinical Brief */}
          {activeTab === 'brief' && (
            <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <User className="w-4 h-4 text-mediblue-600" />
                Patient Medical Record Summary
              </h3>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Name:</span>
                  <span className="font-bold text-slate-800">John Doe</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Age / Gender:</span>
                  <span className="font-bold text-slate-800">38 Yrs / Male</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Blood Group:</span>
                  <span className="font-bold text-slate-800">O+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Known Allergies:</span>
                  <span className="font-bold text-rose-600">Penicillin, Pollen</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Chronic Conditions:</span>
                  <span className="font-bold text-slate-800">Mild Hypertension</span>
                </div>
              </div>

              <div className="bg-mediblue-50/70 p-3 rounded-xl border border-mediblue-100 text-mediblue-900 space-y-1">
                <div className="font-bold">Reason for Today's Visit:</div>
                <p className="leading-relaxed">
                  Patient reports mild chest flutter and shortness of breath after 20 minutes of brisk uphill jogging.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
