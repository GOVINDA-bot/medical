import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  Stethoscope, 
  Calendar, 
  Clock, 
  Video, 
  User, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Star, 
  Activity, 
  Send, 
  Plus, 
  Pill,
  Check,
  ChevronRight,
  ClipboardList
} from 'lucide-react';

export default function DoctorDashboardPage({ setActivePage, setConsultationRoomId }) {
  const { user, profile } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAppForRx, setSelectedAppForRx] = useState(null);
  const [rxNotes, setRxNotes] = useState('');
  const [rxMedication, setRxMedication] = useState('');
  const [savingRx, setSavingRx] = useState(false);

  useEffect(() => {
    async function loadDoctorData() {
      try {
        setLoading(true);
        const apps = await api.getAppointments();
        setAppointments(apps);
      } catch (err) {
        console.error("Failed to load doctor appointments:", err);
      } finally {
        setLoading(false);
      }
    }
    loadDoctorData();
  }, []);

  const handleStartConsultation = (roomId) => {
    setConsultationRoomId(roomId);
    setActivePage('telemedicine');
  };

  const handleCompleteConsultation = async (appId) => {
    try {
      await api.updateAppointment(appId, { status: 'Completed' });
      setAppointments(prev => prev.map(a => a.id === appId ? { ...a, status: 'Completed' } : a));
    } catch (err) {
      alert("Error completing consultation: " + err.message);
    }
  };

  const handleSavePrescription = async (e) => {
    e.preventDefault();
    if (!selectedAppForRx) return;
    setSavingRx(true);
    try {
      // 1. Update appointment with prescription
      await api.updateAppointment(selectedAppForRx.id, {
        status: 'Completed',
        notes: rxNotes,
        prescription: rxMedication
      });

      // 2. Add to patient's official digital medical records
      await api.createMedicalRecord({
        patient_id: selectedAppForRx.patient_id,
        title: `Telemedicine Prescription (${profile?.specialization || 'Clinical'})`,
        record_type: 'Prescription',
        record_date: new Date().toISOString().split('T')[0],
        diagnosis: rxNotes || 'Consultation Completed',
        prescriptions: [
          { name: rxMedication, dose: "As Directed", frequency: "Standard Protocol", duration: "7 days" }
        ],
        notes: `Issued during remote telemedicine session by ${profile?.name || user?.name}`
      });

      setAppointments(prev => prev.map(a => a.id === selectedAppForRx.id ? {
        ...a,
        status: 'Completed',
        prescription: rxMedication,
        notes: rxNotes
      } : a));

      setSelectedAppForRx(null);
      setRxNotes('');
      setRxMedication('');
      alert("Prescription generated & attached to patient record successfully!");
    } catch (err) {
      alert("Error saving prescription: " + err.message);
    } finally {
      setSavingRx(false);
    }
  };

  const upcoming = appointments.filter(a => a.status === 'Upcoming');
  const completed = appointments.filter(a => a.status === 'Completed');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Doctor Header Banner */}
      <div className="bg-gradient-to-r from-primary-800 via-primary-700 to-mediblue-800 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-white/15 p-1 border border-white/20 shrink-0">
              <img 
                src={profile?.avatar_url || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300"} 
                alt={profile?.name || "Doctor"} 
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <div className="space-y-1">
              <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-white/20 text-xs font-semibold">
                <Stethoscope className="w-3.5 h-3.5" />
                <span>Licensed Healthcare Provider</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold">{profile?.name || user?.name || "Doctor"}</h1>
              <p className="text-primary-100 text-xs sm:text-sm">
                {profile?.specialization || 'Specialist'} • {profile?.hospital || 'Hospital Network'} • {profile?.qualification || 'MD'}
              </p>
              <div className="flex items-center gap-3 pt-1 text-xs">
                <span className="flex items-center gap-1 font-bold bg-amber-400 text-slate-900 px-2 py-0.5 rounded">
                  <Star className="w-3 h-3 fill-slate-900" /> {profile?.rating || '4.9'} ({profile?.total_reviews || '340'} reviews)
                </span>
                <span className="bg-white/15 px-2.5 py-0.5 rounded border border-white/20">
                  Fee: <strong>${profile?.consultation_fee || '65'}/session</strong>
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              onClick={() => setActivePage('telemedicine')}
              className="px-5 py-3 bg-white text-primary-900 hover:bg-slate-100 font-bold rounded-xl text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
            >
              <Video className="w-4 h-4 text-primary-700" />
              Open Telemedicine Hub
            </button>
          </div>
        </div>
      </div>

      {/* Quick Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Today's Queue</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">{upcoming.length}</div>
            <div className="text-[11px] text-primary-600 mt-1">Pending appointments</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Completed Sessions</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">{completed.length}</div>
            <div className="text-[11px] text-emerald-600 mt-1">Prescriptions issued</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Consultation Fee</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">${profile?.consultation_fee || '65'}</div>
            <div className="text-[11px] text-mediblue-600 mt-1">Direct tele-billing</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-mediblue-50 text-mediblue-600 flex items-center justify-center">
            <Activity className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Practice Days</div>
            <div className="text-xs font-bold text-slate-800 mt-2 truncate max-w-[150px]">{profile?.available_days || 'Mon - Fri'}</div>
            <div className="text-[11px] text-slate-500 mt-1">Tele-clinic active</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Appointments Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Scheduled Patient Consultations</h2>
            <p className="text-xs text-slate-500 mt-0.5">Manage patient video calls, review clinical history and write prescriptions.</p>
          </div>
          <span className="text-xs font-bold bg-primary-100 text-primary-800 px-3 py-1 rounded-full">
            {upcoming.length} Upcoming
          </span>
        </div>

        {loading ? (
          <div className="py-12 text-center text-slate-400">Loading patient schedule...</div>
        ) : appointments.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-sm">No appointments on record.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
                  <th className="py-3 px-4">Patient Info</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Symptoms / Reason</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {appointments.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-4 px-4">
                      <div className="font-bold text-slate-900">{app.patient_name}</div>
                      <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                        <span>Age: {app.patient_age || '35'}</span>
                        <span>•</span>
                        <span className="text-rose-600 font-medium">Allergy: {app.patient_allergies || 'None'}</span>
                      </div>
                    </td>

                    <td className="py-4 px-4">
                      <div className="font-medium text-slate-800">{app.appointment_date}</div>
                      <div className="text-xs text-mediblue-600 font-semibold">{app.appointment_time}</div>
                    </td>

                    <td className="py-4 px-4 max-w-xs">
                      <p className="text-xs text-slate-600 line-clamp-2">
                        {app.reason || 'General Health Consultation'}
                      </p>
                      {app.prescription && (
                        <div className="text-xs text-primary-700 font-medium mt-1">
                          Rx: {app.prescription}
                        </div>
                      )}
                    </td>

                    <td className="py-4 px-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                        app.status === 'Upcoming' ? 'bg-amber-100 text-amber-800' :
                        app.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {app.status}
                      </span>
                    </td>

                    <td className="py-4 px-4 text-right space-x-2">
                      {app.status === 'Upcoming' && (
                        <>
                          <button
                            onClick={() => handleStartConsultation(app.meeting_room_id)}
                            className="px-3 py-1.5 bg-mediblue-600 hover:bg-mediblue-700 text-white rounded-lg text-xs font-bold shadow-xs inline-flex items-center gap-1.5"
                          >
                            <Video className="w-3.5 h-3.5" /> Start Call
                          </button>
                          <button
                            onClick={() => setSelectedAppForRx(app)}
                            className="px-3 py-1.5 bg-primary-100 hover:bg-primary-200 text-primary-800 rounded-lg text-xs font-bold inline-flex items-center gap-1"
                          >
                            <Pill className="w-3.5 h-3.5" /> Prescribe
                          </button>
                        </>
                      )}
                      {app.status === 'Completed' && (
                        <span className="text-xs font-semibold text-emerald-600 flex items-center justify-end gap-1">
                          <Check className="w-4 h-4" /> Consultation Done
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Prescription Writing Modal */}
      {selectedAppForRx && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-primary-600" />
                <h3 className="font-bold text-slate-900 text-lg">Write Digital Prescription</h3>
              </div>
              <button
                onClick={() => setSelectedAppForRx(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl text-xs space-y-1">
              <div><strong>Patient:</strong> {selectedAppForRx.patient_name}</div>
              <div><strong>Reason for Consultation:</strong> {selectedAppForRx.reason}</div>
              <div><strong>Allergies:</strong> <span className="text-rose-600 font-semibold">{selectedAppForRx.patient_allergies || 'None'}</span></div>
            </div>

            <form onSubmit={handleSavePrescription} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Diagnosis / Clinical Findings
                </label>
                <textarea
                  rows="2"
                  required
                  value={rxNotes}
                  onChange={(e) => setRxNotes(e.target.value)}
                  placeholder="e.g. Mild viral upper respiratory infection, stable vitals."
                  className="w-full p-2.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                ></textarea>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Prescription / Medications & Dosage
                </label>
                <textarea
                  rows="3"
                  required
                  value={rxMedication}
                  onChange={(e) => setRxMedication(e.target.value)}
                  placeholder="e.g. Amoxicillin 500mg, 1 tablet 3 times a day for 5 days after food."
                  className="w-full p-2.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedAppForRx(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingRx}
                  className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-primary-600 hover:bg-primary-700 shadow-md flex items-center gap-1.5"
                >
                  {savingRx ? 'Issuing...' : 'Sign & Issue Prescription'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
