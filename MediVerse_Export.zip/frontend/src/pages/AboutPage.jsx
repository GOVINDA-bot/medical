import React from 'react';
import { 
  HeartPulse, 
  Bot, 
  Video, 
  ShieldCheck, 
  Users, 
  Globe2, 
  Award, 
  CheckCircle2, 
  ArrowRight,
  Stethoscope,
  Building,
  Target
} from 'lucide-react';

export default function AboutPage({ setActivePage }) {
  return (
    <div className="space-y-16 py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Hero Section */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-mediblue-700 bg-mediblue-50 px-3.5 py-1.5 rounded-full border border-mediblue-200">
          About MediVerse
        </span>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
          Connecting People to Better Healthcare.
        </h1>
        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          MediVerse was engineered with a clear, singular vision: making certified medical specialist care and AI-powered health guidance accessible, affordable, and immediate for everyone—especially underserved and rural populations.
        </p>
      </div>

      {/* Mission & Problem Statement Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-mediblue-100 text-mediblue-700 flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">The Problem We Address</h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Over 60 million people residing in rural and underserved districts face acute healthcare disparities. Long travel times to tier-1 hospitals, weeks-long waitlists to see a cardiologist or neurologist, and confusing internet searches frequently delay essential early interventions.
          </p>
          <ul className="space-y-2 text-xs text-slate-700 pt-2">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-rose-500 shrink-0" />
              <span>Average 52-mile travel distance to reach certified specialists.</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-rose-500 shrink-0" />
              <span>Excessive ER overcrowding for non-emergency primary care inquiries.</span>
            </li>
          </ul>
        </div>

        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-primary-100 text-primary-700 flex items-center justify-center">
            <Globe2 className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Our Digital Solution</h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            MediVerse strips away unnecessary barriers. By concentrating specifically on <strong>Telemedicine video visits</strong> and <strong>AI-assisted symptom triage</strong>, we enable any patient with an internet connection to speak to a doctor and receive actionable medical guidance within minutes.
          </p>
          <ul className="space-y-2 text-xs text-slate-700 pt-2">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Real-time HD video consultations requiring no downloads.</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>24/7 AI health assistant prioritizing patient safety and specialist referral.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Two Core Pillars */}
      <div className="bg-slate-50 rounded-3xl border border-slate-200 p-8 sm:p-12 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-primary-700">Focused Architecture</h3>
          <h4 className="text-3xl font-extrabold text-slate-900">Two Core Pillars</h4>
          <p className="text-xs sm:text-sm text-slate-600">
            MediVerse avoids unproven VR/AR gimmicks, focusing strictly on high-impact, real-world telemedicine tools.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-mediblue-100 text-mediblue-700 flex items-center justify-center">
              <Video className="w-5 h-5" />
            </div>
            <h5 className="text-lg font-bold text-slate-900">1. Telemedicine Consultations</h5>
            <p className="text-xs text-slate-600 leading-relaxed">
              Integrated WebRTC streaming connecting patients with certified cardiologists, dermatologists, pediatricians, neurologists, and general practitioners. Full in-call chat, screen sharing, and electronic prescriptions.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <h5 className="text-lg font-bold text-slate-900">2. AI Health Assistant</h5>
            <p className="text-xs text-slate-600 leading-relaxed">
              Algorithmic clinical triage evaluating user symptom descriptions, determining urgency levels, recommending safe at-home palliative measures, and directly connecting patients to appropriate medical specialists.
            </p>
          </div>
        </div>
      </div>

      {/* Medical Advisory Board Preview */}
      <div className="space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-mediblue-700">Clinical Leadership</span>
          <h3 className="text-3xl font-extrabold text-slate-900">Chief Medical Specialists</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center space-y-3 shadow-xs">
            <img
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300"
              alt="Dr. Sarah Jenkins"
              className="w-24 h-24 rounded-full object-cover mx-auto shadow-sm"
            />
            <div>
              <div className="font-bold text-slate-900 text-base">Dr. Sarah Jenkins, MD, FACC</div>
              <div className="text-xs text-primary-700 font-semibold">Chief of Cardiology</div>
              <div className="text-[11px] text-slate-500 mt-1">14 years • Harvard Medical School</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center space-y-3 shadow-xs">
            <img
              src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=300"
              alt="Dr. Marcus Vance"
              className="w-24 h-24 rounded-full object-cover mx-auto shadow-sm"
            />
            <div>
              <div className="font-bold text-slate-900 text-base">Dr. Marcus Vance, MD, PhD</div>
              <div className="text-xs text-primary-700 font-semibold">Director of Neurology</div>
              <div className="text-[11px] text-slate-500 mt-1">12 years • Johns Hopkins University</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center space-y-3 shadow-xs">
            <img
              src="https://images.unsplash.com/photo-1594824813571-638f02614d3f?auto=format&fit=crop&q=80&w=300"
              alt="Dr. Elena Rostova"
              className="w-24 h-24 rounded-full object-cover mx-auto shadow-sm"
            />
            <div>
              <div className="font-bold text-slate-900 text-base">Dr. Elena Rostova, MD, FAAD</div>
              <div className="text-xs text-primary-700 font-semibold">Head of Dermatology</div>
              <div className="text-[11px] text-slate-500 mt-1">9 years • Stanford University</div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
