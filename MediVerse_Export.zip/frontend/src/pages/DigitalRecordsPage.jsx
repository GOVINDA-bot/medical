import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { 
  FileText, 
  Calendar, 
  User, 
  Stethoscope, 
  Download, 
  Plus, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Pill, 
  Activity, 
  Search,
  ExternalLink,
  ShieldCheck,
  Printer
} from 'lucide-react';

export default function DigitalRecordsPage({ setActivePage }) {
  const { user, profile } = useAuth();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [filterType, setFilterType] = useState('All');
  const [showUploadModal, setShowUploadModal] = useState(false);

  // New record form state
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState('Lab Report');
  const [newDiagnosis, setNewDiagnosis] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    async function loadRecords() {
      try {
        setLoading(true);
        const data = await api.getMedicalRecords(
          user?.role === 'patient' ? profile?.id : null,
          filterType === 'All' ? null : filterType
        );
        setRecords(data);
      } catch (err) {
        console.error("Failed to load records:", err);
      } finally {
        setLoading(false);
      }
    }
    loadRecords();
  }, [filterType, user, profile]);

  const handleCreateRecord = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const newRec = await api.createMedicalRecord({
        patient_id: profile?.id || 1,
        title: newTitle,
        record_type: newType,
        record_date: new Date().toISOString().split('T')[0],
        diagnosis: newDiagnosis,
        notes: newNotes,
        prescriptions: [],
        vitals: { "Recorded On": "Self / Clinic Portal", "Status": "Verified Normal" }
      });

      setRecords(prev => [newRec, ...prev]);
      setShowUploadModal(false);
      setNewTitle('');
      setNewDiagnosis('');
      setNewNotes('');
      alert("Medical record successfully registered in your digital vault!");
    } catch (err) {
      alert("Error adding record: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handlePrintSummary = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-mediblue-700 bg-mediblue-50 px-3 py-1 rounded-full border border-mediblue-200">
            Encrypted Health Vault
          </span>
          <h1 className="text-3xl font-extrabold text-slate-900 mt-2">
            Digital Health Records
          </h1>
          <p className="text-xs sm:text-sm text-slate-600">
            Centralized repository of clinical summaries, digital prescriptions, and laboratory reports.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handlePrintSummary}
            className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold shadow-xs flex items-center gap-2 transition-colors"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print / Export Records</span>
          </button>

          <button
            onClick={() => setShowUploadModal(true)}
            className="px-4 py-2 bg-mediblue-600 hover:bg-mediblue-700 text-white rounded-xl text-xs font-bold shadow-sm flex items-center gap-2 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Medical Record</span>
          </button>
        </div>
      </div>

      {/* Patient Health Summary Card */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl p-6 shadow-md flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-white/10 text-primary-400 flex items-center justify-center shrink-0">
            <User className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs text-slate-400">Record Holder</div>
            <div className="font-bold text-lg text-white">{user?.name || "John Doe"}</div>
            <div className="text-xs text-slate-300">{user?.email || "patient@mediverse.com"}</div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="bg-white/10 px-3 py-1.5 rounded-lg border border-white/10">
            <span className="text-slate-400">Blood Group: </span>
            <strong className="text-white font-bold">{profile?.blood_group || 'O+'}</strong>
          </div>
          <div className="bg-white/10 px-3 py-1.5 rounded-lg border border-white/10">
            <span className="text-slate-400">Allergies: </span>
            <strong className="text-rose-300 font-bold">{profile?.allergies || 'Penicillin, Pollen'}</strong>
          </div>
          <div className="bg-white/10 px-3 py-1.5 rounded-lg border border-white/10">
            <span className="text-slate-400">Chronic: </span>
            <strong className="text-amber-300 font-bold">{profile?.chronic_conditions || 'Mild Hypertension'}</strong>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {['All', 'Prescription', 'Lab Report', 'Clinical Summary'].map((type) => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              filterType === type
                ? 'bg-mediblue-600 text-white shadow-sm'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {type === 'All' ? 'All Records' : `${type}s`}
          </button>
        ))}
      </div>

      {/* Records Listing */}
      {loading ? (
        <div className="py-20 text-center text-slate-400">Accessing digital records...</div>
      ) : records.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 space-y-2">
          <FileText className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-bold text-slate-800 text-base">No records found for this category</h3>
          <p className="text-xs text-slate-500">Add a new record or complete a telemedicine consultation to generate a prescription.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {records.map((rec) => (
            <div
              key={rec.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    rec.record_type === 'Prescription' ? 'bg-primary-100 text-primary-800' :
                    rec.record_type === 'Lab Report' ? 'bg-mediblue-100 text-mediblue-800' :
                    'bg-slate-100 text-slate-700'
                  }`}>
                    {rec.record_type}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] text-slate-500">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{rec.record_date}</span>
                  </div>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-base">{rec.title}</h3>
                  <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                    <Stethoscope className="w-3.5 h-3.5 text-primary-600" />
                    <span>{rec.doctor_name || 'Self-Reported Laboratory'}</span>
                  </div>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl text-xs space-y-1">
                  <div className="text-slate-500 font-medium">Diagnosis / Assessment:</div>
                  <div className="font-bold text-slate-800">{rec.diagnosis || 'Clinical evaluation'}</div>
                  {rec.notes && (
                    <p className="text-slate-600 text-[11px] mt-1 line-clamp-2">{rec.notes}</p>
                  )}
                </div>

                {/* Prescriptions preview */}
                {rec.prescriptions && rec.prescriptions.length > 0 && (
                  <div className="text-xs space-y-1 border-t border-slate-100 pt-2">
                    <div className="font-semibold text-primary-800 flex items-center gap-1 text-[11px]">
                      <Pill className="w-3.5 h-3.5" /> Prescribed Medications:
                    </div>
                    {rec.prescriptions.map((p, idx) => (
                      <div key={idx} className="bg-primary-50/50 p-1.5 rounded text-[11px] text-primary-900 font-medium">
                        {p.name} - {p.dose} ({p.frequency})
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Verified
                </span>
                <button
                  onClick={() => setSelectedRecord(rec)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-mediblue-50 text-slate-700 hover:text-mediblue-700 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
                >
                  <span>View Details</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Record Details Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-primary-700 bg-primary-100 px-2.5 py-0.5 rounded">
                  {selectedRecord.record_type}
                </span>
                <h2 className="text-xl font-bold text-slate-900 mt-2">{selectedRecord.title}</h2>
                <div className="text-xs text-slate-500 mt-0.5">
                  Issued on {selectedRecord.record_date} by {selectedRecord.doctor_name || 'Medical Center'}
                </div>
              </div>
              <button
                onClick={() => setSelectedRecord(null)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {/* Diagnosis */}
            <div className="bg-slate-50 p-4 rounded-xl text-xs space-y-1">
              <span className="text-slate-400 font-semibold uppercase">Clinical Diagnosis</span>
              <div className="text-sm font-bold text-slate-900">{selectedRecord.diagnosis || 'Routine Health Review'}</div>
              <p className="text-slate-600 mt-1">{selectedRecord.notes}</p>
            </div>

            {/* Prescriptions Table */}
            {selectedRecord.prescriptions && selectedRecord.prescriptions.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Pill className="w-4 h-4 text-primary-600" />
                  Prescribed Medication Regimen
                </h4>
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-slate-600 font-bold text-[11px]">
                      <tr>
                        <th className="p-2.5">Medication</th>
                        <th className="p-2.5">Dose</th>
                        <th className="p-2.5">Frequency</th>
                        <th className="p-2.5">Duration</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedRecord.prescriptions.map((rx, idx) => (
                        <tr key={idx} className="bg-white">
                          <td className="p-2.5 font-bold text-slate-900">{rx.name}</td>
                          <td className="p-2.5 text-slate-600">{rx.dose}</td>
                          <td className="p-2.5 text-slate-600">{rx.frequency}</td>
                          <td className="p-2.5 text-slate-600">{rx.duration}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Vitals / Parameters */}
            {selectedRecord.vitals && Object.keys(selectedRecord.vitals).length > 0 && (
              <div className="space-y-2">
                <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-mediblue-600" />
                  Recorded Parameters & Clinical Indices
                </h4>
                <div className="bg-slate-50 p-3 rounded-xl grid grid-cols-2 gap-2 text-xs">
                  {Object.entries(selectedRecord.vitals).map(([k, v]) => (
                    <div key={k} className="p-2 bg-white rounded-lg border border-slate-200">
                      <div className="text-[10px] text-slate-500 font-medium">{k}</div>
                      <div className="font-bold text-slate-900 mt-0.5">{String(v)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <span className="text-xs text-slate-400 font-mono">ID: REF-{selectedRecord.id}829</span>
              <button
                onClick={() => setSelectedRecord(null)}
                className="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold"
              >
                Close Record
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Upload/Add Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-lg">Add Medical Record</h3>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleCreateRecord} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Record Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Annual Blood Pressure Checkup Report"
                  className="w-full p-2.5 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Record Type</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-300"
                >
                  <option value="Lab Report">Lab Report</option>
                  <option value="Prescription">Prescription</option>
                  <option value="Clinical Summary">Clinical Summary</option>
                  <option value="Vaccination">Vaccination</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Diagnosis / Summary</label>
                <input
                  type="text"
                  required
                  value={newDiagnosis}
                  onChange={(e) => setNewDiagnosis(e.target.value)}
                  placeholder="e.g. Normal Cardiac Sinus Rhythm"
                  className="w-full p-2.5 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Physician / Clinical Notes</label>
                <textarea
                  rows="3"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Additional physician comments, vitals, or instructions..."
                  className="w-full p-2.5 rounded-lg border border-slate-300"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-mediblue-600 text-white font-bold rounded-lg hover:bg-mediblue-700 shadow-sm"
                >
                  {submitting ? 'Saving...' : 'Save Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
