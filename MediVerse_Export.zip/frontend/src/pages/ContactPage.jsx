import React, { useState } from 'react';
import { api } from '../services/api';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp,
  ShieldAlert,
  Headphones
} from 'lucide-react';

const FAQS = [
  {
    q: "How does an online video consultation work on MediVerse?",
    a: "After selecting a specialist and choosing a convenient time slot, you'll receive a secure video room link. At appointment time, click 'Join Video Call' from your dashboard or booking confirmation. The call opens directly in your browser with camera, microphone, and in-call messaging."
  },
  {
    q: "Can doctors prescribe medication during telemedicine consultations?",
    a: "Yes. Authorized physicians can write official digital prescriptions during the video call using our Electronic Prescription Pad. The prescription automatically saves to your Digital Health Records and can be downloaded or fulfilled at your preferred pharmacy."
  },
  {
    q: "Does the AI Health Assistant provide official medical diagnoses?",
    a: "No. MediVerse AI is designed strictly for preliminary triage and health education. It evaluates your symptoms, identifies emergency red flags, offers at-home comfort guidance, and recommends the appropriate medical specialist to consult. It does not replace an in-person or telemedicine evaluation by a qualified doctor."
  },
  {
    q: "How are patient health records and personal information protected?",
    a: "MediVerse implements role-based access control (RBAC). Only the patient and their consulting physician have access to private health history, lab results, and prescriptions. All data transmissions are encrypted via industry standard protocols."
  },
  {
    q: "What should I do if I am experiencing a severe medical emergency?",
    a: "If you or someone around you is suffering from crushing chest pain, difficulty breathing, sudden stroke symptoms, severe trauma, or uncontrollable bleeding, immediately dial your local emergency services (e.g. 911 or 112) or proceed to the nearest hospital emergency room."
  }
];

export default function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submittedMessage, setSubmittedMessage] = useState(null);
  const [openFaq, setOpenFaq] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await api.submitContact({ name, email, phone, subject, message });
      setSubmittedMessage(res.message);
      setName('');
      setEmail('');
      setPhone('');
      setSubject('');
      setMessage('');
    } catch (err) {
      alert("Error sending message: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-mediblue-700 bg-mediblue-50 px-3 py-1 rounded-full border border-mediblue-200">
          We Are Here To Help
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Contact MediVerse Support & Clinical Care
        </h1>
        <p className="text-sm sm:text-base text-slate-600">
          Have questions about appointment booking, telemedicine technology, or partnerships? Reach our dedicated team anytime.
        </p>
      </div>

      {/* Emergency Notice */}
      <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-xs text-rose-900 flex items-center gap-3 max-w-4xl mx-auto">
        <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
        <div>
          <strong>Medical Emergency Notice:</strong> For immediate, life-threatening symptoms, do not use the contact form. Please dial <strong>911 / 112</strong> or your local emergency medical provider directly.
        </div>
      </div>

      {/* Grid: Support Info + Contact Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Support Channels (1 Col) */}
        <div className="space-y-4">
          
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-mediblue-100 text-mediblue-700 flex items-center justify-center">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-semibold uppercase">24/7 Toll-Free Hotline</div>
              <div className="text-lg font-bold text-slate-900 mt-0.5">1-800-MEDIVERSE</div>
              <div className="text-xs text-slate-500 mt-1">Available around the clock for patient support</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-semibold uppercase">Clinical Email Desk</div>
              <div className="text-base font-bold text-slate-900 mt-0.5">care@mediverse.health</div>
              <div className="text-xs text-slate-500 mt-1">Average response time: under 2 hours</div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-semibold uppercase">Headquarters</div>
              <div className="text-sm font-bold text-slate-900 mt-0.5">MediVerse Health Technologies Inc.</div>
              <div className="text-xs text-slate-500 mt-1">450 Innovation Parkway, Healthcare Tower 4, Tech City</div>
            </div>
          </div>

        </div>

        {/* Contact Form (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-sm space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Send us a Message</h2>
            <p className="text-xs text-slate-500 mt-1">Our clinical coordination team will review and reply promptly.</p>
          </div>

          {submittedMessage && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{submittedMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full p-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Your Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full p-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Phone Number (Optional)</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+1 (555) 000-0000"
                  className="w-full p-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Subject</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Appointment Inquiries / Technical Question"
                  className="w-full p-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Detailed Message</label>
              <textarea
                rows="4"
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe your inquiry or feedback..."
                className="w-full p-3 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-mediblue-500"
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-3 bg-mediblue-600 hover:bg-mediblue-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              {submitting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>Send Message</span>
                  <Send className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>

      </div>

      {/* Frequently Asked Questions Accordion */}
      <div className="max-w-4xl mx-auto space-y-6 pt-6">
        <div className="text-center space-y-1">
          <h3 className="text-2xl font-bold text-slate-900">Frequently Asked Questions</h3>
          <p className="text-xs text-slate-500">Common questions about MediVerse telemedicine and AI capabilities.</p>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-all"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? -1 : idx)}
                className="w-full p-4 text-left font-bold text-sm text-slate-900 flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <span>{faq.q}</span>
                {openFaq === idx ? (
                  <ChevronUp className="w-4 h-4 text-mediblue-600 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>

              {openFaq === idx && (
                <div className="px-4 pb-4 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
